"""
UPI / Payment Fraud Checker
-----------------------------
User koi SMS / WhatsApp message / call-script paste karta hai, aur hum
usme common UPI fraud ke "red flags" dhoondte hain.

IMPORTANT IDEA: Real UPI fraud zyada tar hacking se nahi, balki
SOCIAL ENGINEERING (logo ko urgent/confuse feel karake) se hota hai.
Isliye hum simple KEYWORD + PATTERN based detection use kar rahe hain -
ye approach beginner-friendly, fast, aur explainable hai (kisi bhi
"black box" ML model ki zaroorat nahi).
"""

import re
from modules.utils import calculate_risk_level

# Har red-flag pattern ke saath uska "weight" - kitna risky signal hai.
# Weight jitna zyada, utna bada warning sign.
RED_FLAGS = {
    r"\bkyc\b.*(update|expire|block)": 25,
    r"scan.*qr.*(receive|refund|cashback)": 25,
    r"collect request": 20,
    r"\botp\b": 15,
    r"\bupi pin\b": 20,
    r"screen.?share|anydesk|teamviewer|quick support": 25,
    r"account.*(block|suspend|freeze)": 20,
    r"refund|cashback|lottery|winner|prize": 15,
    r"urgent|immediately|within 24 hours|act now": 15,
    r"customer care|bank official|rbi officer|npci": 10,
    r"click.*link|click here": 10,
}

MAX_SCORE = sum(RED_FLAGS.values())


def check_upi_message(message: str) -> dict:
    """
    message: user ne paste kiya hua text (SMS/WhatsApp/call script)
    return : score, risk level, matched red-flags, aur safety tips
    """
    text = message.lower()
    matched = []
    score = 0

    for pattern, weight in RED_FLAGS.items():
        if re.search(pattern, text):
            score += weight
            matched.append(pattern)

    risk_level, percentage = calculate_risk_level(score, MAX_SCORE)

    return {
        "score": score,
        "max_score": MAX_SCORE,
        "percentage": round(percentage, 1),
        "risk_level": risk_level,
        "matched_flags": matched,
        "tips": _get_tips(matched),
    }


def _get_tips(matched_flags: list) -> list:
    """Matched flags ke hisaab se relevant safety tips return karta hai."""
    tips = []
    if any("qr" in f for f in matched_flags):
        tips.append(
            "Kabhi bhi 'refund/cashback' lene ke liye QR code scan na karo - "
            "paise RECEIVE karne ke liye QR scan ya PIN dalne ki zarurat nahi padti."
        )
    if any("otp" in f or "pin" in f for f in matched_flags):
        tips.append(
            "OTP/UPI PIN kabhi kisi ko mat batao - bank ya NPCI kabhi "
            "phone/SMS pe OTP nahi maangte."
        )
    if any("screen" in f for f in matched_flags):
        tips.append(
            "Kisi bhi unknown caller ke kehne pe AnyDesk/TeamViewer jaisi "
            "screen-sharing app install mat karo."
        )
    if any("kyc" in f for f in matched_flags):
        tips.append(
            "KYC update sirf bank ki official app/branch se karo, kisi SMS "
            "link se nahi."
        )
    if not tips:
        tips.append(
            "Koi major red flag nahi mila, but hamesha unknown numbers se "
            "aaye payment requests ko verify karke hi approve karo."
        )
    return tips
