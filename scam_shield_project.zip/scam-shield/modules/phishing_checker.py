"""
Phishing Link / Email Checker
--------------------------------
User ek link (URL) ya pura email/message text paste karta hai.
Hum do tarah ki checking karte hain:
 1. Agar text mein koi URL hai -> uske structure mein red flags dhoondte hain
    (jaise IP-address domain, lookalike spelling, suspicious TLD, etc.)
 2. Pure text mein bhi suspicious "urgency" language check karte hain.
"""

import re
from modules.utils import calculate_risk_level

URL_PATTERN = re.compile(r"https?://[^\s]+|www\.[^\s]+")

URL_RED_FLAGS = {
    r"\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}": 25,        # IP address as domain
    r"bit\.ly|tinyurl|t\.co|is\.gd|cutt\.ly": 15,      # URL shorteners
    r"-{2,}": 10,                                       # too many hyphens
    r"@": 20,                                           # '@' trick in URLs
    r"\.(xyz|top|club|tk|info|loan|win)(/|$)": 15,      # commonly abused TLDs
    r"(paypa1|amaz0n|g00gle|micr0soft|netf1ix)": 25,    # lookalike brand spelling
}

TEXT_RED_FLAGS = {
    r"verify.*account|confirm.*identity": 15,
    r"suspend|locked|limited access": 15,
    r"urgent|immediately|expire(s)? (today|soon)": 15,
    r"click here|click the link below": 10,
    r"win.*prize|lottery|congratulations.*selected": 15,
    r"update.*payment|billing.*information": 15,
    r"dear (customer|user|sir/madam)": 10,
}

MAX_SCORE = sum(URL_RED_FLAGS.values()) + sum(TEXT_RED_FLAGS.values())


def check_phishing(content: str) -> dict:
    """
    content: user ne paste kiya hua link ya email/message text
    return : score, risk level, matched flags, found URLs, aur tips
    """
    text = content.lower().strip()
    matched = []
    score = 0

    # URLs ke andar ke red flags check karo
    urls = URL_PATTERN.findall(text)
    for url in urls:
        for pattern, weight in URL_RED_FLAGS.items():
            if re.search(pattern, url):
                score += weight
                matched.append(f"URL pattern: {pattern}")

    # Pure text ke andar suspicious language check karo
    for pattern, weight in TEXT_RED_FLAGS.items():
        if re.search(pattern, text):
            score += weight
            matched.append(f"Text pattern: {pattern}")

    risk_level, percentage = calculate_risk_level(score, MAX_SCORE)

    return {
        "score": score,
        "max_score": MAX_SCORE,
        "percentage": round(percentage, 1),
        "risk_level": risk_level,
        "matched_flags": matched,
        "urls_found": urls,
        "tips": _get_tips(matched, urls),
    }


def _get_tips(matched_flags: list, urls: list) -> list:
    tips = []
    if urls:
        tips.append(
            "Link pe click karne se pehle hamesha official website ka URL "
            "browser mein khud type karke check karo."
        )
    if any("verify" in f or "confirm" in f for f in matched_flags):
        tips.append(
            "Koi genuine company email/SMS se 'verify your account' bolke "
            "direct link nahi bhejti - apne account mein khud login karke "
            "check karo."
        )
    if any("urgent" in f or "expire" in f for f in matched_flags):
        tips.append(
            "Urgency create karna (jaise 'expires today') scammers ka "
            "sabse common trick hai - panic mat karo, verify karo."
        )
    if not tips:
        tips.append(
            "Koi major red flag nahi mila, but phir bhi sender ka pura "
            "email address carefully check karo (spelling mismatch ho sakta hai)."
        )
    return tips
