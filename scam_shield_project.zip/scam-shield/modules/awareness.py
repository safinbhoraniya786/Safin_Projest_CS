"""
Cyber Awareness Tips
-----------------------
Simple educational content - har category ke liye quick safety tips.
Ye module sirf static data return karta hai, koi detection logic nahi -
isका purpose sirf "education/awareness" hai (jo internship ka core goal bhi tha).
"""

TIPS = {
    "UPI / Payment Safety": [
        "Paise RECEIVE karne ke liye kabhi UPI PIN nahi dalna padta - "
        "PIN sirf PAY karte waqt lagta hai.",
        "Kisi bhi 'refund/cashback' ke naam pe aaya QR code scan mat karo.",
        "Bank/NPCI kabhi phone call ya SMS pe OTP nahi maangte.",
        "Screen-sharing apps (AnyDesk, TeamViewer) kisi unknown caller ke "
        "kehne pe install mat karo.",
        "Fraud hone par turant 1930 (National Cyber Crime Helpline) pe "
        "call karo ya cybercrime.gov.in pe report karo.",
    ],
    "Phishing / Email Safety": [
        "Link pe click karne se pehle URL carefully padho - spelling "
        "mismatch dhoondo (jaise paypa1.com).",
        "Urgency wale messages ('account expire ho jayega') pe panic "
        "mat karo.",
        "Sender ka pura email address check karo, sirf display name pe "
        "trust mat karo.",
        "Important account access ke liye browser mein official website "
        "khud type karke jao.",
    ],
    "Job Scam Safety": [
        "Koi bhi genuine job offer paisa maang ke nahi aata.",
        "Company ki official website/LinkedIn page pe job listing "
        "verify karo.",
        "HR ka email company domain se hona chahiye, generic "
        "Gmail/Yahoo se nahi.",
        "Bank details ya OTP kisi bhi 'recruitment process' mein "
        "share mat karo.",
    ],
}


def get_all_tips() -> dict:
    return TIPS
