"""
Shared helper functions used by all the fraud-checker modules.
"""


def calculate_risk_level(score: int, max_score: int):
    """
    Numeric score ko simple risk level (Low/Medium/High) mein convert karta hai.

    score      -> kitne red-flag points match hue
    max_score  -> total possible points (sabhi red flags ka sum)

    Returns: (risk_level_text, percentage)
    """
    percentage = (score / max_score) * 100 if max_score > 0 else 0

    if percentage >= 60:
        return "HIGH RISK", percentage
    elif percentage >= 30:
        return "MEDIUM RISK", percentage
    else:
        return "LOW RISK", percentage
