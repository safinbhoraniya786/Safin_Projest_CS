"""
Fake Job Offer Checker
-------------------------
User job offer message/email ka text paste karta hai.
Hum common recruitment-scam red flags check karte hain - jaise
"registration fee" maangna, bina interview ke selection, etc.
"""

import re
from modules.utils import calculate_risk_level

RED_FLAGS = {
    r"registration fee|processing fee|security deposit|training fee": 30,
    r"no interview|without interview|directly selected": 20,
    r"work from home.*(earn|salary).*(per day|daily)": 15,
    r"limited (seats|slots)|hurry|offer valid today": 15,
    r"send.*(money|payment).*(joining|kit|laptop)": 25,
    r"telegram|whatsapp.*(interview|join)": 10,
    r"@gmail\.com|@yahoo\.com": 10,    # "official" offer from a personal email
    r"guaranteed (job|placement|salary)": 15,
    r"pay.*(refundable|advance)": 20,
}

MAX_SCORE = sum(RED_FLAGS.values())


def check_job_offer(message: str) -> dict:
    """
    message: job offer ka pasted text
    return : score, risk level, matched red-flags, aur safety tips
    """
    text = message.lower()
    matched = []
    score = 0

    for pattern, weight in RED_FLAGS.items():
        if re.search(pattern, text):
            score += weight
            matched.append(pattern)

    risk_level, percentage = calculate_risk_level(score, MAX_SCORE)

    return {
        "score": score,
        "max_score": MAX_SCORE,
        "percentage": round(percentage, 1),
        "risk_level": risk_level,
        "matched_flags": matched,
        "tips": _get_tips(matched),
    }


def _get_tips(matched_flags: list) -> list:
    tips = []
    if any("fee" in f or "deposit" in f for f in matched_flags):
        tips.append(
            "Koi bhi genuine company job dene ke liye paisa nahi maangti - "
            "'registration/processing fee' maangna bada red flag hai."
        )
    if any("interview" in f for f in matched_flags):
        tips.append(
            "Bina interview ke direct selection ka dawa karna suspicious "
            "hai - genuine hiring mein screening process hota hai."
        )
    if any("gmail" in f or "yahoo" in f for f in matched_flags):
        tips.append(
            "Company ka official email hamesha company domain "
            "(@companyname.com) se aata hai, generic Gmail/Yahoo se nahi."
        )
    if not tips:
        tips.append(
            "Koi major red flag nahi mila, but phir bhi company ki "
            "official website pe job listing verify kar lo."
        )
    return tips
