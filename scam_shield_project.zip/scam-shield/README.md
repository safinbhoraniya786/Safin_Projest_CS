# 🛡️ Scam Shield — All-in-One Cyber Fraud Detection & Awareness Platform

A beginner-friendly **Python (Streamlit)** web app that helps people check
suspicious messages, links, and job offers for common scam red-flags —
built as a Cybersecurity Internship project.

## Why this project?

Cybercrime is one of the fastest-growing problems worldwide. Phishing alone
accounts for the large majority of cyberattacks, and in India, UPI fraud and
fake job-offer scams have become extremely common because they rely on
*tricking people* rather than hacking systems. Most beginner projects build
only **one** checker — Scam Shield combines **three** of the most common
fraud types into a single platform, plus an awareness/education section,
so more people can actually benefit from it.

## What it does

| Module | What you paste | What it checks |
|---|---|---|
| 💸 UPI/Payment Fraud Checker | A suspicious SMS/WhatsApp message | KYC scam, QR-refund scam, OTP/PIN requests, screen-share requests, urgency language |
| 🔗 Phishing Link/Email Checker | A link or email/message text | Suspicious URL structure (IP address, lookalike domains, shorteners), urgency/verification language |
| 💼 Fake Job Offer Checker | A job offer message/email | Registration/processing fees, no-interview selection, "send money for joining kit" |
| 📚 Awareness Tips | — | Quick, simple safety tips for each category |

Each checker gives a **risk score** (Low / Medium / High), shows exactly
*which red flags matched*, and gives relevant safety tips — so it's not
just a yes/no answer, it teaches the user *why* something looks risky.

## How it works (in simple terms)

Instead of a complex AI/ML model, this project uses a **rule-based scoring
system**:
1. Each fraud type has a list of common red-flag patterns (keywords/phrases),
   each with a "weight" (how risky that signal is).
2. When you paste a message, the app checks it against every pattern using
   Python's `re` (regex) module.
3. Matched patterns add up to a score, which is converted into a percentage
   and a Low/Medium/High risk label.

This makes the logic **fully explainable** — you can literally point to the
exact line of code that flagged something, which is great for demos and
viva questions.

## Project Structure

```
scam-shield/
├── app.py                     # Main Streamlit app (UI + navigation)
├── requirements.txt           # Python dependencies (just streamlit)
├── README.md
└── modules/
    ├── __init__.py
    ├── utils.py                # Shared risk-level calculation
    ├── upi_checker.py           # UPI/payment fraud detection logic
    ├── phishing_checker.py      # Phishing link/email detection logic
    ├── job_checker.py           # Fake job offer detection logic
    └── awareness.py             # Static safety-tips content
```

## How to run it

```bash
# 1. Install dependencies
pip install -r requirements.txt

# 2. Run the app
streamlit run app.py
```

It will open automatically in your browser at `http://localhost:8501`.

## Advantages

- Combines 3 fraud types + awareness in one platform (most projects do only one)
- Simple, explainable logic — no "black box" ML, easy to explain to anyone
- Beginner-friendly Python code (regex + dictionaries, no heavy libraries)
- Gives actionable tips, not just a risk score — genuinely useful for non-technical users
- Easy to extend later (just add more patterns, or a new checker module)

## Limitations

- Rule-based detection can miss new/unseen scam wording it hasn't been told about (a real product would combine this with a trained ML model and a live database of reported scam numbers/URLs)
- It checks *text patterns*, not live data — e.g. it can't verify in real time whether a UPI ID or phone number has actually been reported for fraud
- The phishing checker's maximum possible score includes both URL-based and text-based flags, so plain text without any link will naturally score a bit lower even if very suspicious

## Future Improvements

- Connect to a live database (e.g. via crowdsourced reports) of known scam numbers/URLs
- Add a simple ML model (scikit-learn) trained on a phishing-URL dataset as an optional second opinion
- Add a browser extension version for real-time link checking
