"""
Scam Shield - All-in-One Cyber Fraud Detection & Awareness Platform
-------------------------------------------------------------------------
Ye main Streamlit app file hai. Yahan se sidebar navigation dikhate hain
aur user ke selection ke hisaab se sahi checker module call karte hain.

Run karne ke liye:
    pip install -r requirements.txt
    streamlit run app.py
"""

import streamlit as st
from modules.upi_checker import check_upi_message
from modules.phishing_checker import check_phishing
from modules.job_checker import check_job_offer
from modules.awareness import get_all_tips

st.set_page_config(
    page_title="Scam Shield",
    page_icon="🛡️",
    layout="centered",
)


def show_result(result: dict):
    """Result dictionary ko sundar tarike se screen pe dikhata hai."""
    risk = result["risk_level"]

    if "HIGH" in risk:
        st.error(f"⚠️ {risk}  ({result['percentage']}% red flags matched)")
    elif "MEDIUM" in risk:
        st.warning(f"⚠️ {risk}  ({result['percentage']}% red flags matched)")
    else:
        st.success(f"✅ {risk}  ({result['percentage']}% red flags matched)")

    st.progress(min(result["percentage"] / 100, 1.0))

    with st.expander(f"Matched red flags ({len(result['matched_flags'])})"):
        if result["matched_flags"]:
            for flag in result["matched_flags"]:
                st.write(f"- `{flag}`")
        else:
            st.write("Koi red flag match nahi hua.")

    st.subheader("Safety Tips")
    for tip in result["tips"]:
        st.write(f"💡 {tip}")


def home_page():
    st.title("🛡️ Scam Shield")
    st.write(
        "Ek hi platform mein teen alag-alag fraud checkers — UPI/Payment "
        "fraud, Phishing links/emails, aur Fake job offers — taaki aap "
        "online scams se khud ko aur apne logo ko bacha saken."
    )
    st.info(
        "👈 Sidebar se koi bhi checker choose karo, suspicious message/link "
        "paste karo, aur turant risk level dekho."
    )

    col1, col2, col3 = st.columns(3)
    col1.metric("UPI Fraud (India, FY25)", "10.64 Lakh+ cases")
    col2.metric("Phishing emails/day", "3.4 Billion+")
    col3.metric("Attacks starting w/ phishing", "~90%")
    st.caption("Source: National Cyber Crime data & industry phishing reports (2026)")


def upi_page():
    st.title("💸 UPI / Payment Fraud Checker")
    st.write("Koi suspicious SMS, WhatsApp message ya call script yahan paste karo:")
    message = st.text_area("Message paste karo:", height=150, key="upi_input")

    if st.button("Check for Fraud", key="upi_btn"):
        if message.strip():
            result = check_upi_message(message)
            show_result(result)
        else:
            st.warning("Pehle koi message paste karo.")


def phishing_page():
    st.title("🔗 Phishing Link / Email Checker")
    st.write("Koi suspicious link ya pura email/message text yahan paste karo:")
    content = st.text_area("Link/Email/Message paste karo:", height=150, key="phish_input")

    if st.button("Check for Phishing", key="phish_btn"):
        if content.strip():
            result = check_phishing(content)
            show_result(result)
        else:
            st.warning("Pehle koi link ya text paste karo.")


def job_page():
    st.title("💼 Fake Job Offer Checker")
    st.write("Job offer message ya email ka text yahan paste karo:")
    message = st.text_area("Job offer text paste karo:", height=150, key="job_input")

    if st.button("Check Job Offer", key="job_btn"):
        if message.strip():
            result = check_job_offer(message)
            show_result(result)
        else:
            st.warning("Pehle job offer ka text paste karo.")


def awareness_page():
    st.title("📚 Cyber Awareness - Safety Tips")
    tips = get_all_tips()
    for category, tip_list in tips.items():
        st.subheader(category)
        for tip in tip_list:
            st.write(f"• {tip}")


PAGES = {
    "🏠 Home": home_page,
    "💸 UPI Fraud Checker": upi_page,
    "🔗 Phishing Checker": phishing_page,
    "💼 Job Offer Checker": job_page,
    "📚 Awareness Tips": awareness_page,
}


def main():
    st.sidebar.title("Scam Shield 🛡️")
    choice = st.sidebar.radio("Navigate", list(PAGES.keys()))
    PAGES[choice]()
    st.sidebar.markdown("---")
    st.sidebar.caption("Cybersecurity Internship Project")


if __name__ == "__main__":
    main()
