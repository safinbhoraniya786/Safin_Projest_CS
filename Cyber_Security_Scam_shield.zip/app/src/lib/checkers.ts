export interface CheckResult {
  score: number;
  percentage: number;
  maxScore: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
  matchedFlags: { pattern: string; weight: number; description: string }[];
  tips: string[];
  category: 'UPI' | 'PHISHING' | 'JOB';
  checkedAt: string;
}

// ─── UPI FRAUD CHECKER ───
const UPI_RED_FLAGS: { pattern: RegExp; weight: number; description: string }[] = [
  { pattern: /\bkyc\b.*\b(update|expire|blocked?|suspend|verify|pending|compromised)\b/gi, weight: 25, description: 'KYC update/expire/blocked threat' },
  { pattern: /\bkyc\b.*\b(link|form|website|portal|page)\b/gi, weight: 25, description: 'KYC link/portal request' },
  { pattern: /scan.*qr.*(receive|refund|cashback|money|payment)/gi, weight: 30, description: 'QR scan for refund/cashback scam' },
  { pattern: /(scan|send).*qr.*code/gi, weight: 25, description: 'QR code scan request' },
  { pattern: /\botp\b.*\b(share|send|tell|provide|give|forward)\b/gi, weight: 25, description: 'OTP sharing request' },
  { pattern: /\b(pin\b.*\b(share|send|tell|provide|give)|\bupi\s*pin\b)/gi, weight: 30, description: 'UPI PIN sharing request' },
  { pattern: /\b(screen\s*share|anydesk|teamviewer|remote\s*access|quick\s*support)\b/gi, weight: 30, description: 'Screen share / remote access request' },
  { pattern: /\b(card\s*(block|expire|expiring|deactivate)|\bloan\b.*\b(reject|approve|process))/gi, weight: 20, description: 'Card block/expire or loan process threat' },
  { pattern: /(account.*\b(suspend|blocked?|hold|freeze|restriction|limit|deactivate)\b|\bblock.*account)/gi, weight: 25, description: 'Account suspension/block threat' },
  { pattern: /\b(click\s*link|click\s*here|tap\s*here|visit\s*link)\b/gi, weight: 20, description: 'Click link instruction' },
  { pattern: /\b(urgent|immediately|hurry|asap|right\s*now|act\s*now|last\s*chance|deadline)\b/gi, weight: 15, description: 'Urgency/pressure language' },
  { pattern: /(reward|won|winner|prize|lottery|lucky\s*draw|cash\s*prize|free\s*money)/gi, weight: 20, description: 'Reward/lottery/prize mention' },
  { pattern: /(\bbank\b|\bsbi\b|\bhdfc\b|\bicici\b|\baxis\b|\bpnb\b|\bobc\b|\bbob\b).*\b(verify|confirm|update|secure)\b/gi, weight: 20, description: 'Bank name + verification request' },
  { pattern: /\b(paytm|phonepe|gpay|google\s*pay|amazon\s*pay|bhim)\b.*\b(verification|verify|update|kyc|suspend|block)/gi, weight: 20, description: 'Payment app name + threat' },
  { pattern: /\b(credit\s*card|debit\s*card|atm\s*card)\b.*\b(details|number|cvv|otp|pin|expiry)\b/gi, weight: 30, description: 'Card details request' },
  { pattern: /\b(remote|teamviewer|anydesk|screen\s*share|access)\b/gi, weight: 25, description: 'Remote access tool mentioned' },
  { pattern: /\b(complete|processing)\s*\b(fee|charge|payment|amount)\b/gi, weight: 25, description: 'Processing fee request' },
  { pattern: /(money.*deduct|deduct.*money|amount.*deduct|transaction.*fail)/gi, weight: 15, description: 'Money deduction/transaction failure' },
  { pattern: /\b(refund.*processing|process.*refund|refund.*claim)\b/gi, weight: 20, description: 'Refund processing request' },
  { pattern: /\b(download|install).*\b(app|apk|file|software|update)\b/gi, weight: 25, description: 'App/software download request' },
  { pattern: /\bvpa\b|\bupi\s*id\b/gi, weight: 10, description: 'UPI ID/VPA mentioned' },
  { pattern: /\b(captcha|capture)\b/gi, weight: 15, description: 'Captcha request (misspelled as capture)' },
  { pattern: /(tampering|suspicious.*activity|unusual.*activity|security.*alert)/gi, weight: 20, description: 'Suspicious activity alert' },
];

// ─── PHISHING CHECKER ───
const PHISHING_RED_FLAGS: { pattern: RegExp; weight: number; description: string }[] = [
  { pattern: /https?:\/\/\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3}/gi, weight: 30, description: 'IP address used in URL' },
  { pattern: /(bit\.ly|tinyurl|t\.co|ow\.ly|short\.link|rb\.gy|is\.gd)/gi, weight: 25, description: 'URL shortener detected' },
  { pattern: /(gooogle|paypa1|amaz0n|faceb00k|instagra|twittter|netfl1x|app1e|micr0soft|facebok|arnazon)/gi, weight: 30, description: 'Lookalike/typosquatting domain' },
  { pattern: /https?:\/\/[^\s]*@(?!\w+\.\w+)/gi, weight: 25, description: '@ symbol in URL (credential steal)' },
  { pattern: /\b(verify\s*(your|my)|confirm\s*(your|my)|update\s*(your|my)|secure\s*(your|my))\b.*\b(account|password|details|information|profile)\b/gi, weight: 25, description: 'Verify/confirm account request' },
  { pattern: /\b(login\s*(again|now|here|to|verify)|sign\s*in\s*(again|now|here|to|verify)|authenticate)\b/gi, weight: 25, description: 'Login verification request' },
  { pattern: /\b(password\b.*\b(expire|expiring|reset|change|update)|reset\s*password)\b/gi, weight: 25, description: 'Password expiry/reset' },
  { pattern: /\b(suspended|blocked?|restricted|limited|locked|deactivated)\b.*\b(account|access|profile)\b/gi, weight: 25, description: 'Account suspended/blocked' },
  { pattern: /\b(click\s*link|click\s*here|tap\s*here|click\s*below|tap\s*below)\b/gi, weight: 20, description: 'Click here instruction' },
  { pattern: /\b(urgent|immediately|asap|right\s*now|act\s*now|hurry|limited\s*time|last\s*chance|deadline|within\s*\d+\s*(hour|minute|day))\b/gi, weight: 15, description: 'Urgency/time pressure' },
  { pattern: /(free\s*gift|you\s*won|congratulations.*won|winner|prize|lottery|lucky\s*draw|cash\s*back)/gi, weight: 20, description: 'Prize/winning scam language' },
  { pattern: /\b(verify\s*identity|identity\s*verification|personal\s*information|sensitive\s*information)\b/gi, weight: 25, description: 'Identity/personal info request' },
  { pattern: /\b(tax\s*refund|refund.*processing|claim.*refund|process.*refund)\b/gi, weight: 20, description: 'Tax/refund processing scam' },
  { pattern: /\b(bank\b|\bsbi\b|\bhdfc\b|\bicici\b|\baxis\b).*\b(verify|confirm|update|secure|alert|suspend)\b/gi, weight: 20, description: 'Bank name + action verb' },
  { pattern: /\b(delivery\s*failed|package\s*held|shipping\s*issue|courier|track\s*package)\b/gi, weight: 15, description: 'Delivery/shipping scam' },
  { pattern: /\b(invoice|payment\s*due|unpaid.*bill|overdue|pending\s*payment)\b/gi, weight: 15, description: 'Payment/invoice scam' },
  { pattern: /\b(paypa[li1]|paytm|phonepe|gpay|amazon|flipkart|netflix|apple|google)\b.*\b(suspend|verify|update|unusual)\b/gi, weight: 25, description: 'Brand name + threat' },
  { pattern: /\b(http(?!s)|ftp:\/\/)/gi, weight: 20, description: 'Non-HTTPS URL detected' },
  { pattern: /\b(data\s*breach|compromised|unauthorized\s*access|security\s*incident)\b/gi, weight: 20, description: 'Data breach/security incident claim' },
  { pattern: /\b(download\s*attachment|open\s*attachment|view\s*attachment|see\s*attached)\b/gi, weight: 20, description: 'Attachment download request' },
  { pattern: /\b(enter\s*your\s*(password|pin|otp|cvv|card\s*number))\b/gi, weight: 30, description: 'Credential entry request' },
  { pattern: /\b(from\s*noreply|from\s*no-reply|from\s*donotreply|via\s*sendgrid|via\s*mailgun)\b/gi, weight: 15, description: 'Suspicious sender pattern' },
];

// ─── JOB SCAM CHECKER ───
const JOB_RED_FLAGS: { pattern: RegExp; weight: number; description: string }[] = [
  { pattern: /\b(registration\s*fee|processing\s*fee|application\s*fee|joining\s*fee|training\s*fee|consultation\s*fee)\b/gi, weight: 30, description: 'Registration/joining fee requested' },
  { pattern: /\b(pay\s*\$?\d+|send\s*\$?\d+|deposit\s*\$?\d+|transfer\s*\$?\d+).*(registration|processing|application|joining|training)/gi, weight: 30, description: 'Payment for job processing' },
  { pattern: /\b(no\s*interview|without\s*interview|direct\s*selection|selected\s*without|immediate\s*selection)\b/gi, weight: 30, description: 'No interview selection claim' },
  { pattern: /\b(work\s*from\s*home|wfh).*\b(\$\d+|Rs\.?\s*\d+|\d+\s*(k|thousand|lac|lakh))\b/gi, weight: 20, description: 'WFH with high salary promise' },
  { pattern: /\b(guaranteed\s*(job|placement|hiring|income|salary))\b/gi, weight: 25, description: 'Guaranteed job/income promise' },
  { pattern: /\b(earn\s*\$?\d+.*(daily|weekly|monthly|per\s*day|per\s*week)|\$?\d+.*per\s*day)\b/gi, weight: 20, description: 'Unrealistic earning claims' },
  { pattern: /\b(send\s*money|pay\s*amount|transfer\s*funds).*(kit|material|software|training|course|certificate)/gi, weight: 30, description: 'Pay for kit/materials/software' },
  { pattern: /\b(data\s*entry|typing\s*job|form\s*filling|copy\s*paste|ad\s*posting).*\b(\$\d+|Rs\.?\s*\d+|\d+\s*(k|thousand|lac|lakh))\b/gi, weight: 20, description: 'Data entry job with high pay' },
  { pattern: /\b(whatsapp|telegram)\b.*\b(job|work|interview|group)\b/gi, weight: 15, description: 'Job via WhatsApp/Telegram' },
  { pattern: /\b(urgent\s*hiring|immediate\s*joining|join\s*today|start\s*immediately)\b/gi, weight: 15, description: 'Urgent hiring pressure' },
  { pattern: /\b(no\s*experience\s*required|no\s*qualification|anyone\s*can|freshers?\s*welcome)\b.*\b(high\s*(salary|pay|income))\b/gi, weight: 20, description: 'No experience + high pay combo' },
  { pattern: /\b(limited\s*vacancy|only\s*\d+\s*position|hiring\s*closes?|last\s*few\s*seat)\b/gi, weight: 15, description: 'Limited vacancy pressure' },
  { pattern: /\b(google|microsoft|amazon|apple|meta|facebook).*\b(hiring|job\s*offer|position)\b/gi, weight: 15, description: 'Big brand name drop + job offer' },
  { pattern: /\b(pay\s*first|first\s*pay|payment\s*first|money\s*first)\b/gi, weight: 30, description: 'Pay first before anything' },
  { pattern: /\b(share\s*(aadhaar|aadhar|pan\s*card|bank\s*details|photo|signature))\b/gi, weight: 20, description: 'Personal document request' },
  { pattern: /\b(crypto|bitcoin|ethereum|forex|trading\s*job|investment\s*job)\b/gi, weight: 25, description: 'Crypto/forex trading job' },
  { pattern: /\b(pyramid|mlm|multi.?level|network\s*marketing|chain\s*marketing)\b/gi, weight: 30, description: 'MLM/Pyramid scheme indicators' },
  { pattern: /\b(refer.*friend|referral\s*bonus|bring.*candidate)\b/gi, weight: 15, description: 'Referral-based hiring (MLM pattern)' },
  { pattern: /\b(part.?time.*full.?time.*income|flexible.*hours.*high.*pay)\b/gi, weight: 15, description: 'Part-time with full-time income claim' },
  { pattern: /\b(scan\s*qr|send\s*upi|google\s*pay|phonepe|paytm).*(fee|payment|charge)\b/gi, weight: 25, description: 'UPI payment request for job' },
];

// ─── SAFETY TIPS ───
const UPI_TIPS = [
  'Never share your UPI PIN or OTP with anyone — not even bank employees.',
  'Never scan a QR code to receive money — you only scan to pay.',
  'Banks never ask for KYC updates via links in SMS or WhatsApp.',
  'Do not download AnyDesk or TeamViewer if someone asks during a call.',
  'Always verify UPI IDs before sending money.',
  'Enable UPI app notifications to track all transactions.',
  'If you receive a money request, verify the sender before approving.',
  'Report suspicious UPI transactions immediately to your bank and 1930.',
];

const PHISHING_TIPS = [
  'Always check the URL — look for https:// and correct spelling.',
  'Never click links in emails/SMS asking for login or password.',
  'Hover over links to see the actual destination before clicking.',
  'Use a password manager — it won\'t auto-fill on fake sites.',
  'Enable two-factor authentication (2FA) on all accounts.',
  'Be suspicious of urgent messages pressuring you to act immediately.',
  'Check for grammar errors — phishing messages often have mistakes.',
  'When in doubt, visit the website directly instead of clicking the link.',
];

const JOB_TIPS = [
  'Legitimate employers never ask for money to apply or join.',
  'If there is no interview and you are "selected" — it is a scam.',
  'Research the company — check their official website and LinkedIn.',
  'Never share Aadhaar, PAN, or bank details before verifying the employer.',
  'If salary seems too good for the work — it probably is fake.',
  'Check if the email is from the company\'s official domain.',
  'MLM/chain marketing jobs promising easy money are scams.',
  'Report fake job offers on the National Cyber Crime Portal.',
];

function calculateRiskLevel(percentage: number): 'LOW' | 'MEDIUM' | 'HIGH' {
  if (percentage >= 60) return 'HIGH';
  if (percentage >= 30) return 'MEDIUM';
  return 'LOW';
}

export function checkUpiMessage(text: string): CheckResult {
  const matched: CheckResult['matchedFlags'] = [];
  let totalScore = 0;

  for (const flag of UPI_RED_FLAGS) {
    flag.pattern.lastIndex = 0;
    if (flag.pattern.test(text)) {
      totalScore += flag.weight;
      matched.push({ pattern: flag.pattern.source, weight: flag.weight, description: flag.description });
    }
  }

  const maxScore = UPI_RED_FLAGS.reduce((sum, f) => sum + f.weight, 0);
  const percentage = Math.min(100, Math.round((totalScore / maxScore) * 100));

  return {
    score: totalScore,
    percentage,
    maxScore,
    riskLevel: calculateRiskLevel(percentage),
    matchedFlags: matched,
    tips: UPI_TIPS,
    category: 'UPI',
    checkedAt: new Date().toISOString(),
  };
}

export function checkPhishing(text: string): CheckResult {
  const matched: CheckResult['matchedFlags'] = [];
  let totalScore = 0;

  for (const flag of PHISHING_RED_FLAGS) {
    flag.pattern.lastIndex = 0;
    if (flag.pattern.test(text)) {
      totalScore += flag.weight;
      matched.push({ pattern: flag.pattern.source, weight: flag.weight, description: flag.description });
    }
  }

  const maxScore = PHISHING_RED_FLAGS.reduce((sum, f) => sum + f.weight, 0);
  const percentage = Math.min(100, Math.round((totalScore / maxScore) * 100));

  return {
    score: totalScore,
    percentage,
    maxScore,
    riskLevel: calculateRiskLevel(percentage),
    matchedFlags: matched,
    tips: PHISHING_TIPS,
    category: 'PHISHING',
    checkedAt: new Date().toISOString(),
  };
}

export function checkJobOffer(text: string): CheckResult {
  const matched: CheckResult['matchedFlags'] = [];
  let totalScore = 0;

  for (const flag of JOB_RED_FLAGS) {
    flag.pattern.lastIndex = 0;
    if (flag.pattern.test(text)) {
      totalScore += flag.weight;
      matched.push({ pattern: flag.pattern.source, weight: flag.weight, description: flag.description });
    }
  }

  const maxScore = JOB_RED_FLAGS.reduce((sum, f) => sum + f.weight, 0);
  const percentage = Math.min(100, Math.round((totalScore / maxScore) * 100));

  return {
    score: totalScore,
    percentage,
    maxScore,
    riskLevel: calculateRiskLevel(percentage),
    matchedFlags: matched,
    tips: JOB_TIPS,
    category: 'JOB',
    checkedAt: new Date().toISOString(),
  };
}

export function getRiskColor(level: 'LOW' | 'MEDIUM' | 'HIGH') {
  switch (level) {
    case 'LOW': return { text: 'text-green-400', bg: 'bg-green-500', border: 'border-green-400', glow: 'shadow-green-400/20', light: 'bg-green-400/10' };
    case 'MEDIUM': return { text: 'text-yellow-400', bg: 'bg-yellow-500', border: 'border-yellow-400', glow: 'shadow-yellow-400/20', light: 'bg-yellow-400/10' };
    case 'HIGH': return { text: 'text-red-400', bg: 'bg-red-500', border: 'border-red-400', glow: 'shadow-red-400/20', light: 'bg-red-400/10' };
  }
}

export function getRiskLabel(level: 'LOW' | 'MEDIUM' | 'HIGH') {
  switch (level) {
    case 'LOW': return 'Low Risk - Seems Safe';
    case 'MEDIUM': return 'Medium Risk - Be Cautious';
    case 'HIGH': return 'High Risk - Likely Scam!';
  }
}
