export interface TipCategory {
  id: string;
  title: string;
  icon: string;
  tips: string[];
}

export const tipCategories: TipCategory[] = [
  {
    id: 'upi',
    title: 'UPI & Payment Safety',
    icon: 'Wallet',
    tips: [
      'Never share your UPI PIN or OTP — not even with "bank officials".',
      'Never scan a QR code to RECEIVE money — QR scans are only for paying.',
      'Banks never send KYC update links via SMS or WhatsApp.',
      'Never download AnyDesk, TeamViewer, or similar apps when asked on a call.',
      'Always verify the UPI ID before approving any payment request.',
      'Enable app lock and transaction notifications on your UPI app.',
      'Do not click on links claiming cashback, rewards, or lottery wins.',
      'If someone says "money deducted by mistake, scan QR to get refund" — it is a scam.',
      'Use UPI Lite for small transactions to limit exposure.',
      'Report fraud immediately by calling 1930 or visiting cybercrime.gov.in.',
    ],
  },
  {
    id: 'phishing',
    title: 'Phishing & Email Safety',
    icon: 'MailWarning',
    tips: [
      'Check the sender\'s email address carefully — look for typos in domain names.',
      'Never click links in emails claiming your account is "suspended" or "limited".',
      'Hover over links to see the actual URL before clicking.',
      'Legitimate companies never ask for your password via email.',
      'Enable 2FA on all important accounts (email, banking, social media).',
      'Be suspicious of urgent messages pressuring you to "act now".',
      'Look for grammar mistakes — phishing emails often have poor spelling.',
      'Always visit websites directly by typing the URL instead of clicking links.',
      'Do not open attachments from unknown or unexpected senders.',
      'Use a password manager — it won\'t auto-fill credentials on fake sites.',
    ],
  },
  {
    id: 'job',
    title: 'Job Scam Safety',
    icon: 'Briefcase',
    tips: [
      'Legitimate employers NEVER ask for money to apply or join.',
      'If you are "selected" without any interview — it is 100% a scam.',
      'Research the company on LinkedIn, Glassdoor, and their official website.',
      'Never share Aadhaar, PAN card, or bank details before verifying the employer.',
      'If the salary seems unrealistically high for the work — it is fake.',
      'Check if the email domain matches the company\'s official domain.',
      'MLM, chain marketing, and "refer friends to earn" are scam patterns.',
      'Data entry jobs promising thousands per day are almost always scams.',
      'Crypto/forex trading jobs asking for investment are fraudulent.',
      'Report fake job scams on the National Cyber Crime Portal.',
    ],
  },
  {
    id: 'social',
    title: 'Social Media Safety',
    icon: 'Users',
    tips: [
      'Do not accept friend requests from unknown people.',
      'Never share OTPs received on social media "customer support" chats.',
      'Be cautious of "DM to win iPhone/laptop" posts — they are scams.',
      'Do not share personal photos, address, or travel plans publicly.',
      'Enable privacy settings to limit who can see your posts and info.',
      'Fake customer support accounts are common — verify the blue tick/handle.',
      'Do not click on "shocking video" or "is this you?" links.',
      'Report and block accounts sending suspicious messages or links.',
    ],
  },
  {
    id: 'password',
    title: 'Password & Account Security',
    icon: 'Lock',
    tips: [
      'Use a unique password for every account — never reuse passwords.',
      'Passwords should be at least 12 characters with mixed letters, numbers, symbols.',
      'Use a password manager (Bitwarden, LastPass, 1Password) to store passwords.',
      'Enable Two-Factor Authentication (2FA) on all critical accounts.',
      'Change passwords immediately if you suspect any account compromise.',
      'Do not save passwords on public or shared computers.',
      'Use biometric login (fingerprint/face) where available.',
      'Never share your passwords with friends, family, or colleagues.',
    ],
  },
  {
    id: 'device',
    title: 'Device & Network Security',
    icon: 'Smartphone',
    tips: [
      'Keep your phone and computer OS updated with latest security patches.',
      'Install apps only from official stores (Google Play, App Store).',
      'Do not connect to unknown or public Wi-Fi for banking transactions.',
      'Use a VPN when accessing sensitive information on public networks.',
      'Install a reliable antivirus and keep it updated.',
      'Review app permissions regularly — remove unnecessary access.',
      'Backup important data regularly to cloud or external storage.',
      'Enable "Find My Device" feature on your phone and laptop.',
    ],
  },
];

export const scamStats = [
  { label: 'UPI Fraud Cases (India FY25)', value: '10.64 Lakh+', icon: 'TrendingUp', color: 'text-red-400' },
  { label: 'Phishing Emails Sent/Day', value: '3.4 Billion+', icon: 'Mail', color: 'text-yellow-400' },
  { label: 'Cyber Attacks via Phishing', value: '~90%', icon: 'AlertTriangle', color: 'text-orange-400' },
  { label: 'Average Financial Loss', value: 'Rs. 1.5 Lakh', icon: 'IndianRupee', color: 'text-red-300' },
  { label: 'Job Scam Complaints (Annual)', value: '50,000+', icon: 'Briefcase', color: 'text-purple-400' },
  { label: 'Cases Reported to 1930', value: '7.5 Lakh+', icon: 'Phone', color: 'text-green-400' },
];

export const recentScams = [
  {
    id: 1,
    type: 'UPI',
    title: 'Fake KYC Update SMS',
    description: 'SMS claiming "Your Paytm KYC is expired. Click link to update immediately or account will be blocked."',
    reportedCount: 45200,
    date: '2026-06-25',
  },
  {
    id: 2,
    type: 'PHISHING',
    title: 'Amazon Order Cancellation Scam',
    description: 'Email claiming an Amazon order is cancelled with a "refund link" that steals login credentials.',
    reportedCount: 38400,
    date: '2026-06-24',
  },
  {
    id: 3,
    type: 'JOB',
    title: 'Work From Home Data Entry Scam',
    description: 'WhatsApp message offering Rs. 5000/day for data entry work, asks for Rs. 999 registration fee.',
    reportedCount: 29800,
    date: '2026-06-23',
  },
  {
    id: 4,
    type: 'UPI',
    title: 'QR Code Refund Scam',
    description: 'Caller claims money was sent by mistake, asks victim to scan QR to "receive refund" — money gets deducted.',
    reportedCount: 52300,
    date: '2026-06-22',
  },
  {
    id: 5,
    type: 'PHISHING',
    title: 'SBI Credit Card Limit Increase',
    description: 'Fake SBI email offering credit limit increase with a link to "verify" card details.',
    reportedCount: 21500,
    date: '2026-06-21',
  },
  {
    id: 6,
    type: 'JOB',
    title: 'Fake Google Hiring Scam',
    description: 'Email claiming Google is urgently hiring, no interview needed, asks for software purchase fee.',
    reportedCount: 18700,
    date: '2026-06-20',
  },
];
