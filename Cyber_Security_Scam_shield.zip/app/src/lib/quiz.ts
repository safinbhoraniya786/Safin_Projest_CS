export interface QuizQuestion {
  id: number;
  question: string;
  options: string[];
  correctIndex: number;
  explanation: string;
  category: string;
}

export const quizQuestions: QuizQuestion[] = [
  {
    id: 1,
    question: 'A caller says they are from your bank and asks for your OTP to "verify your account." What should you do?',
    options: [
      'Give them the OTP since they are from the bank',
      'Hang up immediately — banks never ask for OTPs',
      'Ask them to hold while you check with the branch',
      'Give them only half the OTP to be safe',
    ],
    correctIndex: 1,
    explanation: 'Banks NEVER ask for OTPs, PINs, or passwords. Anyone asking for these is a scammer.',
    category: 'UPI',
  },
  {
    id: 2,
    question: 'You get an SMS: "Your Amazon order #45231 is cancelled. Click here for refund." What do you do?',
    options: [
      'Click the link to get the refund quickly',
      'Check your Amazon app directly for order status',
      'Reply to the SMS asking for more details',
      'Call the number in the SMS for help',
    ],
    correctIndex: 1,
    explanation: 'Always check order status directly in the official app/website. Never click links in SMS or emails.',
    category: 'Phishing',
  },
  {
    id: 3,
    question: 'A company offers you a job with "no interview required" and asks for a Rs. 999 registration fee. Is this legit?',
    options: [
      'Yes, many companies charge registration fees',
      'Yes, if they have a professional-looking website',
      'No, legitimate employers never ask for money to join',
      'Maybe, if the salary offer is very high',
    ],
    correctIndex: 2,
    explanation: 'Legitimate employers NEVER ask candidates to pay money to apply or join. This is a classic job scam.',
    category: 'Job',
  },
  {
    id: 4,
    question: 'You receive a WhatsApp message saying "You won Rs. 5,00,000 in a lucky draw! Click to claim." What is this?',
    options: [
      'A genuine lucky draw win',
      'A lottery scam — do not click the link',
      'Could be real if sent by a known contact',
      'Only risky if they ask for bank details',
    ],
    correctIndex: 1,
    explanation: 'Unexpected lottery/prize messages are always scams. No one randomly gives away lakhs of rupees.',
    category: 'General',
  },
  {
    id: 5,
    question: 'Someone sends you a QR code and says "Scan this to receive Rs. 5000." What happens if you scan it?',
    options: [
      'You will receive Rs. 5000 in your account',
      'Money will be DEDUCTED from your account',
      'Nothing will happen, QR codes are safe',
      'It will just show you payment details',
    ],
    correctIndex: 1,
    explanation: 'Scanning a QR code initiates a PAYMENT from your account, not a receipt. You only scan QR codes when YOU are paying.',
    category: 'UPI',
  },
  {
    id: 6,
    question: 'An email from "amaz0n.in" (with a zero) asks you to update your payment details. What should you do?',
    options: [
      'Click the link and update your card details',
      'Ignore it — the domain "amaz0n" with zero is fake',
      'Forward it to Amazon to confirm',
      'Reply asking if this is genuine',
    ],
    correctIndex: 1,
    explanation: 'Lookalike domains (typosquatting) are a common phishing trick. "amaz0n" with a zero is NOT Amazon.',
    category: 'Phishing',
  },
  {
    id: 7,
    question: 'A job offer promises "Earn Rs. 50,000/week working 1 hour/day from home with no experience." Is this real?',
    options: [
      'Yes, many online jobs offer this',
      'Only if they don\'t ask for upfront payment',
      'No, it is a scam — unrealistic pay for little work is a red flag',
      'Maybe if it is from a well-known company',
    ],
    correctIndex: 2,
    explanation: 'If it sounds too good to be true, it is a scam. No legitimate job pays 50K/week for 1 hour of unskilled work.',
    category: 'Job',
  },
  {
    id: 8,
    question: 'Your phone shows a call from "SBI Customer Care." The caller asks for your debit card CVV. What do you do?',
    options: [
      'Provide the CVV since the caller ID shows SBI',
      'Give only the last 2 digits to be safe',
      'Hang up — caller IDs can be faked (spoofing)',
      'Ask them to verify your account number first',
    ],
    correctIndex: 2,
    explanation: 'Caller IDs can be easily spoofed. Banks never ask for CVV, OTP, or PIN over the phone.',
    category: 'UPI',
  },
  {
    id: 9,
    question: 'You get an email with an attachment named "Invoice.pdf.exe". What is the safest action?',
    options: [
      'Open it to check the invoice details',
      'Delete it immediately — .exe files are programs, not documents',
      'Save it and scan with antivirus before opening',
      'Forward it to a friend to check if it is safe',
    ],
    correctIndex: 1,
    explanation: 'Files ending in .exe are executable programs, not documents. "Invoice.pdf.exe" is malware disguised as a PDF.',
    category: 'Phishing',
  },
  {
    id: 10,
    question: 'You receive a message: "Your package delivery failed. Pay Rs. 50 re-delivery fee via this UPI link." What do you do?',
    options: [
      'Pay the small fee to get your package delivered',
      'Check with the courier company using their official website/app',
      'Pay only if the link looks professional',
      'Forward the message to the seller on the shopping app',
    ],
    correctIndex: 1,
    explanation: 'Always verify delivery issues through the official courier website or shopping app. Small fees are a common scam entry point.',
    category: 'General',
  },
  {
    id: 11,
    question: 'Which of the following is the MOST secure password?',
    options: [
      'password123',
      'YourName@2024',
      'Tr0ub4dor&3!xK#',
      'qwertyuiop',
    ],
    correctIndex: 2,
    explanation: 'A strong password has mixed case letters, numbers, symbols, and is at least 12 characters long with no predictable patterns.',
    category: 'Password',
  },
  {
    id: 12,
    question: 'You find a USB drive in the parking lot. What should you do?',
    options: [
      'Plug it in to check if you can find the owner',
      'Hand it over to your IT/security team without plugging it in',
      'Format it and use it for yourself',
      'Plug it in but don\'t open any files',
    ],
    correctIndex: 1,
    explanation: 'USB drives can contain malware that auto-executes when plugged in. Never insert unknown USB drives into your devices.',
    category: 'Device',
  },
  {
    id: 13,
    question: 'A social media "customer support" account DMs you asking for your phone number and OTP. What do you do?',
    options: [
      'Provide the details to get your issue resolved',
      'Check if the account has a blue tick before sharing',
      'Report and block — real support never asks for OTPs via DM',
      'Ask them to verify their identity first',
    ],
    correctIndex: 2,
    explanation: 'Fake customer support accounts are rampant. Real companies never ask for OTPs or passwords via social media DMs.',
    category: 'Social',
  },
  {
    id: 14,
    question: 'What is "vishing" in cybersecurity?',
    options: [
      'A type of computer virus',
      'Phishing done through voice/phone calls',
      'A secure browsing method',
      'Video-based social engineering',
    ],
    correctIndex: 1,
    explanation: 'Vishing = Voice + Phishing. Scammers use phone calls to trick victims into revealing sensitive information.',
    category: 'General',
  },
  {
    id: 15,
    question: 'If you fall victim to an online scam, what should you do FIRST?',
    options: [
      'Post about it on social media',
      'Call 1930 (National Cyber Crime Helpline) immediately',
      'Try to negotiate with the scammer for refund',
      'Wait and see if the problem resolves itself',
    ],
    correctIndex: 1,
    explanation: 'Call 1930 immediately or report at cybercrime.gov.in. Quick reporting increases chances of fund recovery.',
    category: 'General',
  },
];

export function getQuizScoreLabel(score: number, total: number): { label: string; color: string; message: string } {
  const pct = (score / total) * 100;
  if (pct >= 90) return { label: 'Expert', color: 'text-green-400', message: 'Outstanding! You are a cybersecurity expert!' };
  if (pct >= 70) return { label: 'Advanced', color: 'text-green-300', message: 'Great job! You have strong cybersecurity awareness.' };
  if (pct >= 50) return { label: 'Intermediate', color: 'text-yellow-400', message: 'Good effort! There is still room to improve.' };
  if (pct >= 30) return { label: 'Beginner', color: 'text-orange-400', message: 'Keep learning! Cybersecurity awareness is crucial.' };
  return { label: 'Novice', color: 'text-red-400', message: 'Stay alert! Scammers target those who are unaware.' };
}
