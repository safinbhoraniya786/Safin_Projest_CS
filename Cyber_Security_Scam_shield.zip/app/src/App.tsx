import { Routes, Route } from 'react-router';
import Navbar from './components/Navbar';
import MatrixRain from './components/MatrixRain';
import HomePage from './sections/HomePage';
import UpiPage from './sections/UpiPage';
import PhishingPage from './sections/PhishingPage';
import JobPage from './sections/JobPage';
import DashboardPage from './sections/DashboardPage';
import QuizPage from './sections/QuizPage';
import AwarenessPage from './sections/AwarenessPage';
import HistoryPage from './sections/HistoryPage';
import ReportPage from './sections/ReportPage';

export default function App() {
  return (
    <div className="min-h-screen bg-black text-green-50 grid-overlay">
      <MatrixRain />
      <Navbar />
      <main className="lg:ml-64 min-h-screen">
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/upi" element={<UpiPage />} />
          <Route path="/phishing" element={<PhishingPage />} />
          <Route path="/job" element={<JobPage />} />
          <Route path="/dashboard" element={<DashboardPage />} />
          <Route path="/quiz" element={<QuizPage />} />
          <Route path="/awareness" element={<AwarenessPage />} />
          <Route path="/history" element={<HistoryPage />} />
          <Route path="/report" element={<ReportPage />} />
        </Routes>
      </main>
    </div>
  );
}
