import { useState } from 'react';
import { Link, useLocation } from 'react-router';
import {
  Shield,
  Home,
  Wallet,
  Link2,
  Briefcase,
  BarChart3,
  BookOpen,
  ClipboardList,
  Flag,
  Menu,
  X,
  Brain,
} from 'lucide-react';

const navItems = [
  { path: '/', label: 'Home', icon: Home },
  { path: '/upi', label: 'UPI Checker', icon: Wallet },
  { path: '/phishing', label: 'Phishing Checker', icon: Link2 },
  { path: '/job', label: 'Job Checker', icon: Briefcase },
  { path: '/dashboard', label: 'Dashboard', icon: BarChart3 },
  { path: '/quiz', label: 'Cyber Quiz', icon: Brain },
  { path: '/awareness', label: 'Awareness', icon: BookOpen },
  { path: '/history', label: 'History', icon: ClipboardList },
  { path: '/report', label: 'Report Scam', icon: Flag },
];

export default function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const location = useLocation();

  return (
    <>
      {/* Desktop Sidebar */}
      <nav className="fixed left-0 top-0 h-full w-64 bg-black/80 backdrop-blur-xl border-r border-green-500/20 z-50 hidden lg:flex flex-col">
        <div className="p-6 border-b border-green-500/20">
          <Link to="/" className="flex items-center gap-3 group">
            <div className="w-10 h-10 rounded-lg bg-green-500/20 border border-green-500/40 flex items-center justify-center group-hover:bg-green-500/30 transition-all">
              <Shield className="w-5 h-5 text-green-400" />
            </div>
            <div>
              <h1 className="text-lg font-bold text-green-400 tracking-tight">Scam Shield</h1>
              <p className="text-[10px] text-green-500/60 tracking-widest uppercase">Cyber Defense</p>
            </div>
          </Link>
        </div>

        <div className="flex-1 py-4 px-3 space-y-1 overflow-y-auto">
          {navItems.map((item) => {
            const isActive = location.pathname === item.path;
            const Icon = item.icon;
            return (
              <Link
                key={item.path}
                to={item.path}
                className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all duration-200 text-sm ${
                  isActive
                    ? 'bg-green-500/15 text-green-400 border border-green-500/30 shadow-[0_0_10px_rgba(34,197,94,0.1)]'
                    : 'text-green-500/60 hover:text-green-400 hover:bg-green-500/10'
                }`}
              >
                <Icon className="w-4 h-4" />
                <span>{item.label}</span>
                {isActive && (
                  <div className="ml-auto w-1.5 h-1.5 rounded-full bg-green-400 animate-pulse" />
                )}
              </Link>
            );
          })}
        </div>

        <div className="p-4 border-t border-green-500/20">
          <div className="glass-card rounded-lg p-3">
            <p className="text-[10px] text-green-500/50 uppercase tracking-widest mb-1">Emergency</p>
            <p className="text-sm font-bold text-red-400">1930</p>
            <p className="text-[10px] text-green-500/40">National Cyber Crime Helpline</p>
          </div>
        </div>
      </nav>

      {/* Mobile Header */}
      <nav className="fixed top-0 left-0 right-0 h-16 bg-black/90 backdrop-blur-xl border-b border-green-500/20 z-50 lg:hidden flex items-center px-4">
        <Link to="/" className="flex items-center gap-2 mr-auto">
          <Shield className="w-6 h-6 text-green-400" />
          <span className="text-lg font-bold text-green-400">Scam Shield</span>
        </Link>
        <button
          onClick={() => setIsOpen(!isOpen)}
          className="w-10 h-10 flex items-center justify-center rounded-lg bg-green-500/10 border border-green-500/30"
        >
          {isOpen ? <X className="w-5 h-5 text-green-400" /> : <Menu className="w-5 h-5 text-green-400" />}
        </button>
      </nav>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="fixed inset-0 z-40 lg:hidden">
          <div className="absolute inset-0 bg-black/80 backdrop-blur-sm" onClick={() => setIsOpen(false)} />
          <div className="absolute right-0 top-16 bottom-0 w-64 bg-black/95 backdrop-blur-xl border-l border-green-500/20 p-4 space-y-1 overflow-y-auto">
            {navItems.map((item) => {
              const isActive = location.pathname === item.path;
              const Icon = item.icon;
              return (
                <Link
                  key={item.path}
                  to={item.path}
                  onClick={() => setIsOpen(false)}
                  className={`flex items-center gap-3 px-3 py-2.5 rounded-lg transition-all text-sm ${
                    isActive
                      ? 'bg-green-500/15 text-green-400 border border-green-500/30'
                      : 'text-green-500/60 hover:text-green-400 hover:bg-green-500/10'
                  }`}
                >
                  <Icon className="w-4 h-4" />
                  <span>{item.label}</span>
                </Link>
              );
            })}
            <div className="mt-4 p-3 rounded-lg bg-red-500/10 border border-red-500/20">
              <p className="text-[10px] text-red-400/60 uppercase tracking-widest">Emergency</p>
              <p className="text-lg font-bold text-red-400">1930</p>
              <p className="text-[10px] text-green-500/40">National Cyber Crime Helpline</p>
            </div>
          </div>
        </div>
      )}
    </>
  );
}
