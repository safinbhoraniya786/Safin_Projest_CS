import { motion } from 'framer-motion';
import { getRiskColor, getRiskLabel } from '@/lib/checkers';
import type { CheckResult } from '@/lib/checkers';
import RiskMeter from './RiskMeter';
import { AlertTriangle, CheckCircle, AlertCircle, Shield, ChevronDown, ChevronUp } from 'lucide-react';
import { useState } from 'react';

interface ResultCardProps {
  result: CheckResult;
}

export default function ResultCard({ result }: ResultCardProps) {
  const colors = getRiskColor(result.riskLevel);
  const [showFlags, setShowFlags] = useState(true);

  const getIcon = () => {
    switch (result.riskLevel) {
      case 'LOW': return <CheckCircle className="w-8 h-8 text-green-400" />;
      case 'MEDIUM': return <AlertCircle className="w-8 h-8 text-yellow-400" />;
      case 'HIGH': return <AlertTriangle className="w-8 h-8 text-red-400" />;
    }
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.5 }}
      className="w-full max-w-3xl mx-auto"
    >
      {/* Main Result Card */}
      <div className={`glass-card rounded-xl p-6 border ${colors.border} ${colors.glow} shadow-lg`}>
        <div className="flex flex-col md:flex-row items-center gap-6">
          {/* Risk Meter */}
          <RiskMeter percentage={result.percentage} riskLevel={result.riskLevel} />

          {/* Result Details */}
          <div className="flex-1 text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2 mb-2">
              {getIcon()}
              <h3 className={`text-xl font-bold ${colors.text}`}>
                {getRiskLabel(result.riskLevel)}
              </h3>
            </div>
            <p className="text-green-500/60 text-sm mb-3">
              Risk Score: <span className="text-green-400 font-mono">{result.score}/{result.maxScore}</span> points
            </p>
            <div className="flex flex-wrap gap-2 justify-center md:justify-start">
              <span className={`text-xs px-3 py-1 rounded-full border ${colors.border} ${colors.light} ${colors.text}`}>
                {result.matchedFlags.length} red flags detected
              </span>
              <span className="text-xs px-3 py-1 rounded-full border border-green-500/30 bg-green-500/10 text-green-400">
                {result.category} fraud
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Matched Flags */}
      {result.matchedFlags.length > 0 && (
        <motion.div
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="mt-4 glass-card rounded-xl overflow-hidden border border-green-500/10"
        >
          <button
            onClick={() => setShowFlags(!showFlags)}
            className="w-full flex items-center justify-between p-4 hover:bg-green-500/5 transition-colors"
          >
            <div className="flex items-center gap-2">
              <Shield className="w-4 h-4 text-green-400" />
              <span className="text-sm font-medium text-green-400">
                Matched Red Flags ({result.matchedFlags.length})
              </span>
            </div>
            {showFlags ? <ChevronUp className="w-4 h-4 text-green-500/50" /> : <ChevronDown className="w-4 h-4 text-green-500/50" />}
          </button>
          {showFlags && (
            <div className="px-4 pb-4 space-y-2">
              {result.matchedFlags.map((flag, i) => (
                <motion.div
                  key={i}
                  initial={{ opacity: 0, x: -10 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.05 }}
                  className="flex items-center gap-3 p-3 rounded-lg bg-red-500/5 border border-red-500/10"
                >
                  <AlertTriangle className="w-4 h-4 text-red-400 flex-shrink-0" />
                  <div className="flex-1 min-w-0">
                    <p className="text-sm text-green-100">{flag.description}</p>
                    <p className="text-xs text-green-500/40 font-mono truncate">{flag.pattern}</p>
                  </div>
                  <span className="text-xs px-2 py-1 rounded bg-red-500/10 text-red-400 flex-shrink-0">
                    +{flag.weight}
                  </span>
                </motion.div>
              ))}
            </div>
          )}
        </motion.div>
      )}

      {/* Safety Tips */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="mt-4 glass-card rounded-xl p-5 border border-green-500/10"
      >
        <div className="flex items-center gap-2 mb-4">
          <Shield className="w-5 h-5 text-green-400" />
          <h4 className="text-sm font-bold text-green-400 uppercase tracking-wider">Safety Tips</h4>
        </div>
        <div className="grid gap-2">
          {result.tips.map((tip, i) => (
            <motion.div
              key={i}
              initial={{ opacity: 0, x: -10 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ delay: 0.6 + i * 0.05 }}
              className="flex items-start gap-3 p-3 rounded-lg bg-green-500/5 border border-green-500/10"
            >
              <CheckCircle className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
              <p className="text-sm text-green-100/80">{tip}</p>
            </motion.div>
          ))}
        </div>
      </motion.div>
    </motion.div>
  );
}
