import { useEffect, useState } from 'react';
import { getRiskColor } from '@/lib/checkers';

interface RiskMeterProps {
  percentage: number;
  riskLevel: 'LOW' | 'MEDIUM' | 'HIGH';
}

export default function RiskMeter({ percentage, riskLevel }: RiskMeterProps) {
  const colors = getRiskColor(riskLevel);
  const [animatedPct, setAnimatedPct] = useState(0);

  useEffect(() => {
    const timer = setTimeout(() => setAnimatedPct(percentage), 100);
    return () => clearTimeout(timer);
  }, [percentage]);

  const getStrokeColor = () => {
    if (riskLevel === 'LOW') return '#4ade80';
    if (riskLevel === 'MEDIUM') return '#facc15';
    return '#f87171';
  };

  const radius = 80;
  const circumference = 2 * Math.PI * radius;
  const strokeDashoffset = circumference - (animatedPct / 100) * circumference;

  return (
    <div className="flex flex-col items-center gap-3">
      <div className="relative">
        <svg width="200" height="200" className="transform -rotate-90">
          {/* Background circle */}
          <circle
            cx="100"
            cy="100"
            r={radius}
            fill="none"
            stroke="rgba(34, 197, 94, 0.1)"
            strokeWidth="12"
          />
          {/* Progress circle */}
          <circle
            cx="100"
            cy="100"
            r={radius}
            fill="none"
            stroke={getStrokeColor()}
            strokeWidth="12"
            strokeLinecap="round"
            strokeDasharray={circumference}
            strokeDashoffset={strokeDashoffset}
            style={{ transition: 'stroke-dashoffset 1.5s ease-out' }}
            className="drop-shadow-[0_0_8px_rgba(34,197,94,0.5)]"
          />
        </svg>
        {/* Center text */}
        <div className="absolute inset-0 flex flex-col items-center justify-center">
          <span className={`text-4xl font-bold ${colors.text}`}>{animatedPct}%</span>
          <span className={`text-xs uppercase tracking-wider mt-1 px-2 py-0.5 rounded-full ${colors.light} ${colors.text} border ${colors.border}`}>
            {riskLevel}
          </span>
        </div>
      </div>
    </div>
  );
}
