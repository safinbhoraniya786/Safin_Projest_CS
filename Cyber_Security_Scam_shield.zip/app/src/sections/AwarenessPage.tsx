import { useState } from 'react';
import { motion } from 'framer-motion';
import { tipCategories } from '@/lib/tips';
import {
  BookOpen, Wallet, MailWarning, Briefcase,
  Users, Lock, Smartphone, Search, ChevronDown, ChevronUp,
  Shield, ExternalLink,
} from 'lucide-react';

const iconMap: Record<string, React.ReactNode> = {
  Wallet: <Wallet className="w-5 h-5" />,
  MailWarning: <MailWarning className="w-5 h-5" />,
  Briefcase: <Briefcase className="w-5 h-5" />,
  Users: <Users className="w-5 h-5" />,
  Lock: <Lock className="w-5 h-5" />,
  Smartphone: <Smartphone className="w-5 h-5" />,
};

const resources = [
  { title: 'National Cyber Crime Portal', url: 'https://cybercrime.gov.in', desc: 'Report cyber crimes online' },
  { title: 'Cyber Crime Helpline', url: '#', desc: 'Call 1930 for immediate assistance' },
  { title: 'CERT-In', url: 'https://cert-in.org.in', desc: 'Indian Computer Emergency Response Team' },
  { title: 'Stay Safe Online', url: 'https://staysafeonline.in', desc: 'Government cybersecurity awareness portal' },
];

export default function AwarenessPage() {
  const [search, setSearch] = useState('');
  const [expanded, setExpanded] = useState<string | null>('upi');

  const filtered = tipCategories.map((cat) => ({
    ...cat,
    tips: cat.tips.filter((t) => t.toLowerCase().includes(search.toLowerCase())),
  })).filter((cat) => cat.tips.length > 0);

  return (
    <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-green-500/10 border border-green-500/30 mb-4">
            <BookOpen className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 text-glow mb-2">Cyber Awareness</h1>
          <p className="text-green-500/50">Stay informed, stay protected</p>
        </motion.div>

        {/* Search */}
        <div className="relative mb-8">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500/40" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search safety tips..."
            className="w-full bg-black/50 border border-green-500/20 rounded-lg pl-10 pr-4 py-3 text-green-100 placeholder-green-500/30 focus:outline-none focus:border-green-500/50"
          />
        </div>

        {/* Tips Accordion */}
        <div className="space-y-3 mb-12">
          {filtered.map((cat) => (
            <motion.div
              key={cat.id}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-xl border border-green-500/10 overflow-hidden"
            >
              <button
                onClick={() => setExpanded(expanded === cat.id ? null : cat.id)}
                className="w-full flex items-center justify-between p-4 hover:bg-green-500/5 transition-colors"
              >
                <div className="flex items-center gap-3">
                  <div className="w-9 h-9 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center justify-center text-green-400">
                    {iconMap[cat.icon]}
                  </div>
                  <span className="font-medium text-green-400">{cat.title}</span>
                  <span className="text-xs text-green-500/40">({cat.tips.length} tips)</span>
                </div>
                {expanded === cat.id ? (
                  <ChevronUp className="w-4 h-4 text-green-500/40" />
                ) : (
                  <ChevronDown className="w-4 h-4 text-green-500/40" />
                )}
              </button>
              {expanded === cat.id && (
                <motion.div
                  initial={{ opacity: 0, height: 0 }}
                  animate={{ opacity: 1, height: 'auto' }}
                  className="px-4 pb-4"
                >
                  <div className="space-y-2">
                    {cat.tips.map((tip, i) => (
                      <motion.div
                        key={i}
                        initial={{ opacity: 0, x: -10 }}
                        animate={{ opacity: 1, x: 0 }}
                        transition={{ delay: i * 0.03 }}
                        className="flex items-start gap-3 p-3 rounded-lg bg-green-500/5 border border-green-500/10"
                      >
                        <Shield className="w-4 h-4 text-green-400 mt-0.5 flex-shrink-0" />
                        <p className="text-sm text-green-100/80">{tip}</p>
                      </motion.div>
                    ))}
                  </div>
                </motion.div>
              )}
            </motion.div>
          ))}
        </div>

        {/* Resources */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
        >
          <h3 className="text-lg font-bold text-green-400 mb-4 flex items-center gap-2">
            <ExternalLink className="w-5 h-5" /> Official Resources
          </h3>
          <div className="grid sm:grid-cols-2 gap-3">
            {resources.map((res, i) => (
              <a
                key={i}
                href={res.url}
                target="_blank"
                rel="noopener noreferrer"
                className="glass-card rounded-lg p-4 border border-green-500/10 hover:border-green-500/30 hover:bg-green-500/5 transition-all group"
              >
                <h4 className="text-sm font-medium text-green-400 group-hover:text-green-300 transition-colors">{res.title}</h4>
                <p className="text-xs text-green-500/50 mt-1">{res.desc}</p>
              </a>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
