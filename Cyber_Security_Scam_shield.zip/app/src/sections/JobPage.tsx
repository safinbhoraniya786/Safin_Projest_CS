import { Briefcase } from 'lucide-react';
import CheckerPage from './CheckerPage';
import { checkJobOffer } from '@/lib/checkers';

const sampleInputs = [
  {
    label: 'Registration fee scam: Data entry job with upfront payment',
    text: 'URGENT HIRING! Work From Home Data Entry Job. Earn Rs 5000 per day just by typing 100 pages. No experience required. Anyone can apply. Pay Rs 999 registration fee to get started immediately. Limited slots available! Contact on WhatsApp: 98XXXXXXX0',
  },
  {
    label: 'Direct selection scam: No interview, immediate joining',
    text: 'Congratulations! You have been SELECTED for the position of Data Analyst at Google. No interview required based on your profile. Immediate joining available. Send Rs 2500 for document verification and joining kit. Reply YES to confirm.',
  },
  {
    label: 'MLM/Referral scam: "Refer friends and earn"',
    text: 'Amazing opportunity! Join our network marketing team and earn passive income. Just refer 3 friends and get Rs 10000 weekly. No work needed after joining. Joining fee only Rs 1499. Contact us now! This is a limited time offer!',
  },
  {
    label: 'Crypto trading job scam',
    text: 'Hiring Crypto Traders! Work 1 hour daily and earn $500-$1000 per week. No experience needed. We provide complete training. Deposit $100 to start your trading account. Guaranteed returns. WhatsApp us now!',
  },
  {
    label: 'Fake Google/Microsoft hiring scam',
    text: 'Dear Candidate, Microsoft is urgently hiring for Software Engineer positions. Direct placement without interview. Salary: Rs 12 LPA. Send your documents and pay Rs 3000 processing fee to secure your position. Offer valid till tomorrow!',
  },
];

export default function JobPage() {
  return (
    <CheckerPage
      title="Job Scam Checker"
      subtitle="Identify fake job offers, registration fee scams, and pyramid schemes"
      icon={<Briefcase className="w-8 h-8 text-purple-400" />}
      placeholder="Paste job offer message, email, or WhatsApp text here...&#10;&#10;Example: Work-from-home offers, registration fee demands, no-interview selections..."
      checkFunction={checkJobOffer}
      sampleInputs={sampleInputs}
      accentColor="text-purple-400"
    />
  );
}
