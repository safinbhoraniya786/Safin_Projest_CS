import { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { quizQuestions, getQuizScoreLabel } from '@/lib/quiz';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import {
  Brain, CheckCircle, XCircle,
  RotateCcw, Trophy, ChevronRight, Lightbulb,
} from 'lucide-react';

interface QuizAttempt {
  date: string;
  score: number;
  total: number;
}

export default function QuizPage() {
  const [currentQ, setCurrentQ] = useState(0);
  const [selected, setSelected] = useState<number | null>(null);
  const [showAnswer, setShowAnswer] = useState(false);
  const [score, setScore] = useState(0);
  const [finished, setFinished] = useState(false);
  const [attempts, setAttempts] = useLocalStorage<QuizAttempt[]>('scamshield_quiz', []);

  const question = quizQuestions[currentQ];
  const progress = ((currentQ) / quizQuestions.length) * 100;

  const handleSelect = (index: number) => {
    if (showAnswer) return;
    setSelected(index);
    setShowAnswer(true);
    if (index === question.correctIndex) {
      setScore((s) => s + 1);
    }
  };

  const handleNext = () => {
    if (currentQ < quizQuestions.length - 1) {
      setCurrentQ((q) => q + 1);
      setSelected(null);
      setShowAnswer(false);
    } else {
      setFinished(true);
      setAttempts((prev) => [{ date: new Date().toISOString(), score: score + (selected === question.correctIndex ? 1 : 0), total: quizQuestions.length }, ...prev].slice(0, 20));
    }
  };

  const handleRestart = () => {
    setCurrentQ(0);
    setSelected(null);
    setShowAnswer(false);
    setScore(0);
    setFinished(false);
  };

  const currentScore = finished ? score : score + (selected === question.correctIndex ? 1 : 0);
  const scoreLabel = getQuizScoreLabel(currentScore, quizQuestions.length);

  if (finished) {
    return (
      <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
        <div className="max-w-2xl mx-auto">
          <motion.div
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="glass-card rounded-xl p-8 text-center border border-green-500/15"
          >
            <Trophy className={`w-16 h-16 ${scoreLabel.color} mx-auto mb-4`} />
            <h2 className="text-3xl font-bold text-green-400 mb-2">Quiz Complete!</h2>
            <p className={`text-lg ${scoreLabel.color} mb-6`}>{scoreLabel.message}</p>

            <div className="flex justify-center mb-6">
              <RiskMeter percentage={Math.round((currentScore / quizQuestions.length) * 100)} />
            </div>

            <div className="grid grid-cols-3 gap-4 mb-8">
              <div className="p-3 rounded-lg bg-green-500/5 border border-green-500/10">
                <p className="text-2xl font-bold text-green-400">{currentScore}</p>
                <p className="text-xs text-green-500/50">Correct</p>
              </div>
              <div className="p-3 rounded-lg bg-red-500/5 border border-red-500/10">
                <p className="text-2xl font-bold text-red-400">{quizQuestions.length - currentScore}</p>
                <p className="text-xs text-green-500/50">Wrong</p>
              </div>
              <div className="p-3 rounded-lg bg-yellow-500/5 border border-yellow-500/10">
                <p className="text-2xl font-bold text-yellow-400">{Math.round((currentScore / quizQuestions.length) * 100)}%</p>
                <p className="text-xs text-green-500/50">Accuracy</p>
              </div>
            </div>

            <button
              onClick={handleRestart}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-green-500 text-black font-semibold hover:bg-green-400 transition-all"
            >
              <RotateCcw className="w-4 h-4" />
              Retake Quiz
            </button>
          </motion.div>

          {/* Previous Attempts */}
          {attempts.length > 1 && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.3 }}
              className="mt-6 glass-card rounded-xl p-5 border border-green-500/10"
            >
              <h3 className="text-sm font-bold text-green-400 mb-3">Previous Attempts</h3>
              <div className="space-y-2">
                {attempts.slice(1, 6).map((att, i) => (
                  <div key={i} className="flex items-center justify-between p-2 rounded bg-green-500/5">
                    <span className="text-xs text-green-500/50">{new Date(att.date).toLocaleDateString()}</span>
                    <span className="text-sm text-green-400 font-mono">{att.score}/{att.total}</span>
                  </div>
                ))}
              </div>
            </motion.div>
          )}
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
      <div className="max-w-3xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-green-500/10 border border-green-500/30 mb-4">
            <Brain className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 text-glow mb-2">Cyber Awareness Quiz</h1>
          <p className="text-green-500/50">Test your knowledge — {quizQuestions.length} questions</p>
        </motion.div>

        {/* Progress */}
        <div className="mb-6">
          <div className="flex items-center justify-between mb-2">
            <span className="text-xs text-green-500/50">Question {currentQ + 1} of {quizQuestions.length}</span>
            <span className="text-xs text-green-400 font-mono">Score: {score}</span>
          </div>
          <div className="w-full h-2 rounded-full bg-green-500/10 overflow-hidden">
            <motion.div
              className="h-full bg-green-500 rounded-full"
              initial={{ width: 0 }}
              animate={{ width: `${progress}%` }}
              transition={{ duration: 0.3 }}
            />
          </div>
        </div>

        {/* Question Card */}
        <AnimatePresence mode="wait">
          <motion.div
            key={currentQ}
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: -20 }}
            className="glass-card rounded-xl p-6 border border-green-500/15 mb-6"
          >
            <div className="flex items-center gap-2 mb-4">
              <span className="text-xs px-2 py-1 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">
                {question.category}
              </span>
            </div>
            <h3 className="text-lg font-medium text-green-100 mb-6 leading-relaxed">
              {question.question}
            </h3>

            <div className="space-y-3">
              {question.options.map((option, i) => {
                let btnClass = 'border-green-500/20 hover:border-green-500/40 hover:bg-green-500/5';
                if (showAnswer) {
                  if (i === question.correctIndex) {
                    btnClass = 'border-green-500 bg-green-500/20';
                  } else if (i === selected && i !== question.correctIndex) {
                    btnClass = 'border-red-500 bg-red-500/20';
                  } else {
                    btnClass = 'border-green-500/10 opacity-50';
                  }
                } else if (i === selected) {
                  btnClass = 'border-green-500 bg-green-500/10';
                }

                return (
                  <button
                    key={i}
                    onClick={() => handleSelect(i)}
                    disabled={showAnswer}
                    className={`w-full flex items-center gap-3 p-4 rounded-lg border transition-all text-left ${btnClass}`}
                  >
                    <span className="w-7 h-7 rounded-full border border-green-500/30 flex items-center justify-center text-xs text-green-400 flex-shrink-0">
                      {showAnswer && i === question.correctIndex ? (
                        <CheckCircle className="w-4 h-4 text-green-400" />
                      ) : showAnswer && i === selected && i !== question.correctIndex ? (
                        <XCircle className="w-4 h-4 text-red-400" />
                      ) : (
                        String.fromCharCode(65 + i)
                      )}
                    </span>
                    <span className="text-sm text-green-100">{option}</span>
                  </button>
                );
              })}
            </div>

            {/* Explanation */}
            {showAnswer && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="mt-4 p-4 rounded-lg bg-green-500/5 border border-green-500/15"
              >
                <div className="flex items-start gap-2">
                  <Lightbulb className="w-4 h-4 text-yellow-400 mt-0.5 flex-shrink-0" />
                  <p className="text-sm text-green-500/70">{question.explanation}</p>
                </div>
              </motion.div>
            )}
          </motion.div>
        </AnimatePresence>

        {/* Next Button */}
        {showAnswer && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="flex justify-end"
          >
            <button
              onClick={handleNext}
              className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-green-500 text-black font-semibold hover:bg-green-400 transition-all"
            >
              {currentQ < quizQuestions.length - 1 ? 'Next Question' : 'See Results'}
              <ChevronRight className="w-4 h-4" />
            </button>
          </motion.div>
        )}
      </div>
    </div>
  );
}

// Simple circular progress for quiz score
function RiskMeter({ percentage }: { percentage: number }) {
  const radius = 50;
  const circumference = 2 * Math.PI * radius;
  const offset = circumference - (percentage / 100) * circumference;
  const color = percentage >= 70 ? '#4ade80' : percentage >= 40 ? '#facc15' : '#f87171';

  return (
    <div className="relative w-28 h-28">
      <svg className="w-full h-full transform -rotate-90">
        <circle cx="56" cy="56" r={radius} fill="none" stroke="rgba(34,197,94,0.1)" strokeWidth="8" />
        <circle
          cx="56" cy="56" r={radius} fill="none" stroke={color} strokeWidth="8"
          strokeLinecap="round" strokeDasharray={circumference} strokeDashoffset={offset}
          style={{ transition: 'stroke-dashoffset 1s ease-out' }}
        />
      </svg>
      <div className="absolute inset-0 flex flex-col items-center justify-center">
        <span className="text-xl font-bold" style={{ color }}>{percentage}%</span>
      </div>
    </div>
  );
}
