import { Link } from 'react-router';
import { motion } from 'framer-motion';
import {
  Shield, Wallet, Link2, Briefcase, BarChart3,
  ArrowRight, TrendingUp, AlertTriangle,
  Phone, Lock, Zap, Eye, Brain,
} from 'lucide-react';
import { scamStats } from '@/lib/tips';

const features = [
  {
    title: 'UPI Fraud Checker',
    description: 'Scan suspicious payment messages, KYC scams, QR code frauds, and OTP phishing attempts.',
    icon: Wallet,
    path: '/upi',
    color: 'from-green-500/20 to-emerald-500/10',
    borderColor: 'border-green-500/30',
  },
  {
    title: 'Phishing Detector',
    description: 'Analyze suspicious links, emails, and messages for phishing red flags and spoofed domains.',
    icon: Link2,
    path: '/phishing',
    color: 'from-blue-500/20 to-cyan-500/10',
    borderColor: 'border-blue-500/30',
  },
  {
    title: 'Job Scam Checker',
    description: 'Identify fake job offers, registration fee scams, and unrealistic work-from-home schemes.',
    icon: Briefcase,
    path: '/job',
    color: 'from-purple-500/20 to-violet-500/10',
    borderColor: 'border-purple-500/30',
  },
];

const highlights = [
  { icon: Eye, title: 'Explainable AI', desc: 'Every detection shows exactly which red flags matched and why.' },
  { icon: Zap, title: 'Real-time Analysis', desc: 'Instant risk scoring with animated visual feedback.' },
  { icon: Brain, title: 'Learn & Quiz', desc: 'Test your cybersecurity knowledge with 15+ quiz questions.' },
  { icon: Lock, title: 'Privacy First', desc: 'All checks happen locally. No data leaves your device.' },
];

export default function HomePage() {
  return (
    <div className="min-h-screen relative z-10">
      {/* Hero Section */}
      <section className="relative pt-20 lg:pt-0 lg:min-h-screen flex items-center">
        {/* Background image */}
        <div
          className="absolute inset-0 bg-cover bg-center opacity-20"
          style={{ backgroundImage: 'url(/shield-hero.jpg)' }}
        />
        <div className="absolute inset-0 bg-gradient-to-b from-transparent via-black/60 to-black" />

        <div className="relative z-10 max-w-5xl mx-auto px-4 py-16 lg:py-0">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-green-500/10 border border-green-500/30 mb-6">
              <Shield className="w-4 h-4 text-green-400" />
              <span className="text-sm text-green-400">Cybersecurity Defense Platform</span>
            </div>

            <h1 className="text-4xl md:text-6xl lg:text-7xl font-bold mb-6">
              <span className="text-green-400 text-glow">Scam Shield</span>
            </h1>

            <p className="text-lg md:text-xl text-green-500/70 max-w-2xl mx-auto mb-8 leading-relaxed">
              Detect <span className="text-green-400">UPI fraud</span>,{' '}
              <span className="text-green-400">phishing links</span>, and{' '}
              <span className="text-green-400">fake job offers</span> in real-time.
              Stay one step ahead of cybercriminals.
            </p>

            <div className="flex flex-wrap gap-4 justify-center mb-12">
              <Link
                to="/upi"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg bg-green-500 text-black font-semibold hover:bg-green-400 transition-all hover:shadow-[0_0_20px_rgba(34,197,94,0.4)]"
              >
                <Shield className="w-5 h-5" />
                Start Checking
                <ArrowRight className="w-4 h-4" />
              </Link>
              <Link
                to="/quiz"
                className="inline-flex items-center gap-2 px-6 py-3 rounded-lg border border-green-500/40 text-green-400 font-semibold hover:bg-green-500/10 transition-all"
              >
                <Brain className="w-5 h-5" />
                Take Quiz
              </Link>
            </div>
          </motion.div>

          {/* Stats */}
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.4, duration: 0.6 }}
            className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-3"
          >
            {scamStats.map((stat, i) => {
              const Icon = stat.icon === 'TrendingUp' ? TrendingUp :
                stat.icon === 'Mail' ? Phone :
                stat.icon === 'AlertTriangle' ? AlertTriangle :
                stat.icon === 'IndianRupee' ? Wallet :
                stat.icon === 'Briefcase' ? Briefcase :
                Phone;
              return (
                <motion.div
                  key={stat.label}
                  initial={{ opacity: 0, scale: 0.9 }}
                  animate={{ opacity: 1, scale: 1 }}
                  transition={{ delay: 0.5 + i * 0.1 }}
                  className="glass-card rounded-lg p-4 text-center border border-green-500/10"
                >
                  <Icon className={`w-5 h-5 ${stat.color} mx-auto mb-2`} />
                  <p className={`text-lg font-bold ${stat.color}`}>{stat.value}</p>
                  <p className="text-[10px] text-green-500/50 leading-tight mt-1">{stat.label}</p>
                </motion.div>
              );
            })}
          </motion.div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 px-4">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-green-400 mb-3">Three Checkers, One Shield</h2>
            <p className="text-green-500/50">Choose the checker that matches your suspicious message</p>
          </motion.div>

          <div className="grid md:grid-cols-3 gap-6">
            {features.map((feature, i) => {
              const Icon = feature.icon;
              return (
                <motion.div
                  key={feature.title}
                  initial={{ opacity: 0, y: 20 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                >
                  <Link
                    to={feature.path}
                    className={`block glass-card rounded-xl p-6 border ${feature.borderColor} hover:scale-[1.02] transition-all duration-300 group h-full bg-gradient-to-br ${feature.color}`}
                  >
                    <div className={`w-12 h-12 rounded-lg ${feature.borderColor} bg-white/5 flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
                      <Icon className="w-6 h-6 text-green-400" />
                    </div>
                    <h3 className="text-lg font-bold text-green-400 mb-2">{feature.title}</h3>
                    <p className="text-sm text-green-500/60 mb-4">{feature.description}</p>
                    <div className="flex items-center gap-1 text-green-400 text-sm font-medium">
                      Check Now <ArrowRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                    </div>
                  </Link>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Highlights */}
      <section className="py-16 px-4 border-t border-green-500/10">
        <div className="max-w-5xl mx-auto">
          <motion.div
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="text-center mb-12"
          >
            <h2 className="text-2xl md:text-3xl font-bold text-green-400 mb-3">Why Scam Shield?</h2>
            <p className="text-green-500/50">Built to be useful, explainable, and educational</p>
          </motion.div>

          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
            {highlights.map((item, i) => {
              const Icon = item.icon;
              return (
                <motion.div
                  key={item.title}
                  initial={{ opacity: 0, y: 15 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.1 }}
                  className="glass-card rounded-xl p-5 border border-green-500/10 text-center"
                >
                  <div className="w-10 h-10 rounded-lg bg-green-500/10 border border-green-500/20 flex items-center justify-center mx-auto mb-3">
                    <Icon className="w-5 h-5 text-green-400" />
                  </div>
                  <h4 className="text-sm font-bold text-green-400 mb-1">{item.title}</h4>
                  <p className="text-xs text-green-500/50">{item.desc}</p>
                </motion.div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Quick Access CTA */}
      <section className="py-16 px-4 border-t border-green-500/10">
        <div className="max-w-4xl mx-auto text-center">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
          >
            <Shield className="w-12 h-12 text-green-400 mx-auto mb-4 animate-pulse-glow rounded-full" />
            <h2 className="text-2xl md:text-3xl font-bold text-green-400 mb-4">Ready to Protect Yourself?</h2>
            <p className="text-green-500/60 mb-8 max-w-xl mx-auto">
              Paste any suspicious message, link, or job offer and get instant risk analysis.
              Knowledge is your best defense against cyber fraud.
            </p>
            <div className="flex flex-wrap gap-3 justify-center">
              <Link to="/upi" className="px-5 py-2.5 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400 hover:bg-green-500/20 transition-all text-sm font-medium">
                <Wallet className="w-4 h-4 inline mr-2" />UPI Check
              </Link>
              <Link to="/phishing" className="px-5 py-2.5 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 hover:bg-blue-500/20 transition-all text-sm font-medium">
                <Link2 className="w-4 h-4 inline mr-2" />Phishing Check
              </Link>
              <Link to="/job" className="px-5 py-2.5 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400 hover:bg-purple-500/20 transition-all text-sm font-medium">
                <Briefcase className="w-4 h-4 inline mr-2" />Job Check
              </Link>
              <Link to="/dashboard" className="px-5 py-2.5 rounded-lg bg-yellow-500/10 border border-yellow-500/30 text-yellow-400 hover:bg-yellow-500/20 transition-all text-sm font-medium">
                <BarChart3 className="w-4 h-4 inline mr-2" />Analytics
              </Link>
            </div>
          </motion.div>
        </div>
      </section>
    </div>
  );
}
