import { useMemo } from 'react';
import { motion } from 'framer-motion';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getRiskColor } from '@/lib/checkers';
import type { CheckResult } from '@/lib/checkers';
import { recentScams } from '@/lib/tips';
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip,
  PieChart, Pie, Cell, ResponsiveContainer, LineChart, Line,
  Legend,
} from 'recharts';
import {
  BarChart3, TrendingUp, Shield, AlertTriangle,
  CheckCircle, Clock, Activity,
} from 'lucide-react';

const COLORS = {
  LOW: '#4ade80',
  MEDIUM: '#facc15',
  HIGH: '#f87171',
};



export default function DashboardPage() {
  const [history] = useLocalStorage<CheckResult[]>('scamshield_history', []);

  const stats = useMemo(() => {
    const total = history.length;
    const low = history.filter((h) => h.riskLevel === 'LOW').length;
    const medium = history.filter((h) => h.riskLevel === 'MEDIUM').length;
    const high = history.filter((h) => h.riskLevel === 'HIGH').length;

    const upiChecks = history.filter((h) => h.category === 'UPI').length;
    const phishingChecks = history.filter((h) => h.category === 'PHISHING').length;
    const jobChecks = history.filter((h) => h.category === 'JOB').length;

    const avgScore = total > 0
      ? Math.round(history.reduce((sum, h) => sum + h.percentage, 0) / total)
      : 0;

    return { total, low, medium, high, upiChecks, phishingChecks, jobChecks, avgScore };
  }, [history]);

  const riskDistribution = useMemo(() => [
    { name: 'Low Risk', value: stats.low, color: COLORS.LOW },
    { name: 'Medium Risk', value: stats.medium, color: COLORS.MEDIUM },
    { name: 'High Risk', value: stats.high, color: COLORS.HIGH },
  ], [stats]);

  const categoryDistribution = useMemo(() => [
    { name: 'UPI Fraud', count: stats.upiChecks },
    { name: 'Phishing', count: stats.phishingChecks },
    { name: 'Job Scam', count: stats.jobChecks },
  ], [stats]);

  const timelineData = useMemo(() => {
    const last7Days = Array.from({ length: 7 }, (_, i) => {
      const d = new Date();
      d.setDate(d.getDate() - (6 - i));
      return d.toISOString().split('T')[0];
    });

    return last7Days.map((date) => ({
      date: date.slice(5),
      UPI: history.filter((h) => h.category === 'UPI' && h.checkedAt.startsWith(date)).length,
      Phishing: history.filter((h) => h.category === 'PHISHING' && h.checkedAt.startsWith(date)).length,
      Job: history.filter((h) => h.category === 'JOB' && h.checkedAt.startsWith(date)).length,
    }));
  }, [history]);

  const recentChecks = useMemo(() => history.slice(0, 10), [history]);

  return (
    <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
      <div className="max-w-6xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-yellow-500/10 border border-yellow-500/30 mb-4">
            <BarChart3 className="w-8 h-8 text-yellow-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 text-glow mb-2">Analytics Dashboard</h1>
          <p className="text-green-500/50">Track your scam detection activity and trends</p>
        </motion.div>

        {history.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card rounded-xl p-12 text-center border border-green-500/15"
          >
            <Activity className="w-16 h-16 text-green-500/20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-400 mb-2">No Data Yet</h3>
            <p className="text-green-500/50 mb-6">Start checking suspicious messages to see your analytics here.</p>
            <div className="flex flex-wrap gap-3 justify-center">
              <a href="#/upi" className="px-4 py-2 rounded-lg bg-green-500/10 border border-green-500/30 text-green-400 text-sm hover:bg-green-500/20 transition-all">Check UPI Fraud</a>
              <a href="#/phishing" className="px-4 py-2 rounded-lg bg-blue-500/10 border border-blue-500/30 text-blue-400 text-sm hover:bg-blue-500/20 transition-all">Check Phishing</a>
              <a href="#/job" className="px-4 py-2 rounded-lg bg-purple-500/10 border border-purple-500/30 text-purple-400 text-sm hover:bg-purple-500/20 transition-all">Check Job Scam</a>
            </div>
          </motion.div>
        ) : (
          <>
            {/* Stats Cards */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-6">
              {[
                { label: 'Total Checks', value: stats.total, icon: Shield, color: 'text-green-400' },
                { label: 'Avg Risk Score', value: `${stats.avgScore}%`, icon: TrendingUp, color: 'text-yellow-400' },
                { label: 'High Risk Found', value: stats.high, icon: AlertTriangle, color: 'text-red-400' },
                { label: 'Safe Results', value: stats.low, icon: CheckCircle, color: 'text-green-300' },
              ].map((stat, i) => {
                const Icon = stat.icon;
                return (
                  <motion.div
                    key={stat.label}
                    initial={{ opacity: 0, scale: 0.9 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: i * 0.1 }}
                    className="glass-card rounded-xl p-4 border border-green-500/10"
                  >
                    <Icon className={`w-5 h-5 ${stat.color} mb-2`} />
                    <p className={`text-2xl font-bold ${stat.color}`}>{stat.value}</p>
                    <p className="text-xs text-green-500/50">{stat.label}</p>
                  </motion.div>
                );
              })}
            </div>

            {/* Charts Row */}
            <div className="grid md:grid-cols-2 gap-6 mb-6">
              {/* Risk Distribution Pie Chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.2 }}
                className="glass-card rounded-xl p-5 border border-green-500/10"
              >
                <h3 className="text-sm font-bold text-green-400 mb-4 flex items-center gap-2">
                  <AlertTriangle className="w-4 h-4" /> Risk Distribution
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <PieChart>
                    <Pie
                      data={riskDistribution}
                      cx="50%"
                      cy="50%"
                      innerRadius={50}
                      outerRadius={80}
                      dataKey="value"
                      stroke="none"
                    >
                      {riskDistribution.map((entry, index) => (
                        <Cell key={index} fill={entry.color} />
                      ))}
                    </Pie>
                    <Tooltip
                      contentStyle={{
                        background: '#0a0a0a',
                        border: '1px solid rgba(34,197,94,0.3)',
                        borderRadius: '8px',
                        color: '#4ade80',
                      }}
                    />
                    <Legend
                      formatter={(value: string) => <span className="text-green-400 text-xs">{value}</span>}
                    />
                  </PieChart>
                </ResponsiveContainer>
              </motion.div>

              {/* Category Distribution Bar Chart */}
              <motion.div
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.3 }}
                className="glass-card rounded-xl p-5 border border-green-500/10"
              >
                <h3 className="text-sm font-bold text-green-400 mb-4 flex items-center gap-2">
                  <BarChart3 className="w-4 h-4" /> Checks by Category
                </h3>
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={categoryDistribution}>
                    <CartesianGrid strokeDasharray="3 3" stroke="rgba(34,197,94,0.1)" />
                    <XAxis dataKey="name" tick={{ fill: '#4ade80', fontSize: 12 }} />
                    <YAxis tick={{ fill: '#4ade80', fontSize: 12 }} />
                    <Tooltip
                      contentStyle={{
                        background: '#0a0a0a',
                        border: '1px solid rgba(34,197,94,0.3)',
                        borderRadius: '8px',
                        color: '#4ade80',
                      }}
                    />
                    <Bar dataKey="count" fill="#22c55e" radius={[4, 4, 0, 0]} />
                  </BarChart>
                </ResponsiveContainer>
              </motion.div>
            </div>

            {/* Timeline Chart */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.4 }}
              className="glass-card rounded-xl p-5 border border-green-500/10 mb-6"
            >
              <h3 className="text-sm font-bold text-green-400 mb-4 flex items-center gap-2">
                <Clock className="w-4 h-4" /> Activity Timeline (Last 7 Days)
              </h3>
              <ResponsiveContainer width="100%" height={250}>
                <LineChart data={timelineData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(34,197,94,0.1)" />
                  <XAxis dataKey="date" tick={{ fill: '#4ade80', fontSize: 12 }} />
                  <YAxis tick={{ fill: '#4ade80', fontSize: 12 }} />
                  <Tooltip
                    contentStyle={{
                      background: '#0a0a0a',
                      border: '1px solid rgba(34,197,94,0.3)',
                      borderRadius: '8px',
                      color: '#4ade80',
                    }}
                  />
                  <Legend formatter={(value: string) => <span className="text-green-400 text-xs">{value}</span>} />
                  <Line type="monotone" dataKey="UPI" stroke="#22c55e" strokeWidth={2} dot={{ fill: '#22c55e', r: 3 }} />
                  <Line type="monotone" dataKey="Phishing" stroke="#60a5fa" strokeWidth={2} dot={{ fill: '#60a5fa', r: 3 }} />
                  <Line type="monotone" dataKey="Job" stroke="#a78bfa" strokeWidth={2} dot={{ fill: '#a78bfa', r: 3 }} />
                </LineChart>
              </ResponsiveContainer>
            </motion.div>

            {/* Recent Checks Table */}
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.5 }}
              className="glass-card rounded-xl border border-green-500/10 overflow-hidden mb-6"
            >
              <div className="p-5 border-b border-green-500/10">
                <h3 className="text-sm font-bold text-green-400 flex items-center gap-2">
                  <Activity className="w-4 h-4" /> Recent Checks
                </h3>
              </div>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead>
                    <tr className="border-b border-green-500/10">
                      <th className="text-left p-3 text-xs text-green-500/50 font-medium">Time</th>
                      <th className="text-left p-3 text-xs text-green-500/50 font-medium">Category</th>
                      <th className="text-left p-3 text-xs text-green-500/50 font-medium">Score</th>
                      <th className="text-left p-3 text-xs text-green-500/50 font-medium">Risk Level</th>
                      <th className="text-left p-3 text-xs text-green-500/50 font-medium">Flags</th>
                    </tr>
                  </thead>
                  <tbody>
                    {recentChecks.map((check, i) => {
                      const colors = getRiskColor(check.riskLevel);
                      return (
                        <tr key={i} className="border-b border-green-500/5 hover:bg-green-500/5 transition-colors">
                          <td className="p-3 text-xs text-green-500/60">
                            {new Date(check.checkedAt).toLocaleTimeString()}
                          </td>
                          <td className="p-3">
                            <span className="text-xs px-2 py-1 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">
                              {check.category}
                            </span>
                          </td>
                          <td className="p-3 text-xs text-green-400 font-mono">{check.percentage}%</td>
                          <td className="p-3">
                            <span className={`text-xs px-2 py-1 rounded-full ${colors.light} ${colors.text} border ${colors.border}`}>
                              {check.riskLevel}
                            </span>
                          </td>
                          <td className="p-3 text-xs text-green-500/60">{check.matchedFlags.length}</td>
                        </tr>
                      );
                    })}
                  </tbody>
                </table>
              </div>
            </motion.div>
          </>
        )}

        {/* Trending Scams */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.3 }}
        >
          <h3 className="text-lg font-bold text-green-400 mb-4 flex items-center gap-2">
            <TrendingUp className="w-5 h-5" /> Trending Scams (India 2026)
          </h3>
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-4">
            {recentScams.map((scam, i) => (
              <motion.div
                key={scam.id}
                initial={{ opacity: 0, y: 15 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ delay: 0.4 + i * 0.05 }}
                className="glass-card rounded-xl p-4 border border-green-500/10"
              >
                <div className="flex items-center gap-2 mb-2">
                  <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                    scam.type === 'UPI' ? 'border-green-500/30 text-green-400 bg-green-500/10' :
                    scam.type === 'PHISHING' ? 'border-blue-500/30 text-blue-400 bg-blue-500/10' :
                    'border-purple-500/30 text-purple-400 bg-purple-500/10'
                  }`}>
                    {scam.type}
                  </span>
                  <span className="text-[10px] text-green-500/40">{scam.date}</span>
                </div>
                <h4 className="text-sm font-bold text-green-400 mb-1">{scam.title}</h4>
                <p className="text-xs text-green-500/50 mb-3 line-clamp-2">{scam.description}</p>
                <p className="text-[10px] text-red-400/70">
                  <AlertTriangle className="w-3 h-3 inline mr-1" />
                  {scam.reportedCount.toLocaleString()} reports
                </p>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </div>
  );
}
