import { Link2 } from 'lucide-react';
import CheckerPage from './CheckerPage';
import { checkPhishing } from '@/lib/checkers';

const sampleInputs = [
  {
    label: 'Fake Amazon login: Suspicious email asking to verify account',
    text: 'Dear Amazon User, Your account has been temporarily suspended due to unusual activity. Please verify your account by clicking the link below within 24 hours or your account will be permanently deleted. http://amazon-verify-account.tk/login',
  },
  {
    label: 'Bank phishing: Fake SBI email with lookalike domain',
    text: 'Dear SBI Customer, Your Internet Banking access has been blocked due to multiple failed login attempts. To restore access, please update your details immediately: https://sbi-onlinesecurity.com/restore-access.php',
  },
  {
    label: 'URL shortener scam: Bit.ly link claiming tax refund',
    text: 'GOOD NEWS! You are eligible for an Income Tax refund of Rs 45,230. Your refund has been processed. Click here to claim: bit.ly/tax-refund-2026 Claim within 48 hours before it expires!',
  },
  {
    label: 'Prize scam: "You won iPhone 15" with IP address URL',
    text: 'CONGRATULATIONS! You have been selected as the lucky winner of an iPhone 15 Pro! Your prize is ready for delivery. Confirm your shipping details here: http://192.168.45.12/apple-winner/claim.php',
  },
  {
    label: 'Netflix credential theft: Account suspension threat',
    text: 'Dear Netflix User, We were unable to process your recent payment. Your subscription will be suspended within 24 hours. Please update your payment information to continue watching: https://netflix-billing-update.com/payment',
  },
];

export default function PhishingPage() {
  return (
    <CheckerPage
      title="Phishing Detector"
      subtitle="Analyze suspicious links, emails, and messages for phishing attempts"
      icon={<Link2 className="w-8 h-8 text-blue-400" />}
      placeholder="Paste suspicious email content, message text, or URL here...&#10;&#10;Example: Fake login pages, account suspension emails, refund links, prize notifications..."
      checkFunction={checkPhishing}
      sampleInputs={sampleInputs}
      accentColor="text-blue-400"
    />
  );
}
