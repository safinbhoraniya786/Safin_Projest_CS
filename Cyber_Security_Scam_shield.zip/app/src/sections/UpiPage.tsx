import { Wallet } from 'lucide-react';
import CheckerPage from './CheckerPage';
import { checkUpiMessage } from '@/lib/checkers';

const sampleInputs = [
  {
    label: 'KYC scam: "Your Paytm KYC is expired. Click link to update immediately or account will be blocked."',
    text: 'Dear Customer, Your Paytm KYC is EXPIRED. Click the link below to update your KYC immediately within 24 hours or your account will be BLOCKED permanently. http://paytmkyc-update.com/verify',
  },
  {
    label: 'QR refund scam: "I sent money by mistake, scan this QR to return it"',
    text: 'Hi, I accidentally sent Rs 5000 to your account. Please scan this QR code to send it back to me. I really need this money urgently for my mother\'s hospital treatment. Please help!',
  },
  {
    label: 'OTP scam: "Share your OTP to complete the transaction"',
    text: 'This is from SBI Bank. A transaction of Rs 25000 is being processed from your account. If this is not you, share the OTP you just received to block this transaction immediately. Do not delay!',
  },
  {
    label: 'Screen share scam: "Download AnyDesk so I can help you get refund"',
    text: 'Hello, I am calling from Amazon customer care. There was an issue with your recent order. Please download AnyDesk from Play Store so I can connect to your device and process the refund directly.',
  },
  {
    label: 'Cashback reward scam',
    text: 'Congratulations! You have won a cashback reward of Rs 50000 from PhonePe. To claim your reward, click this link and enter your UPI PIN to verify your identity. Limited time offer!',
  },
];

export default function UpiPage() {
  return (
    <CheckerPage
      title="UPI Fraud Checker"
      subtitle="Detect KYC scams, QR frauds, OTP phishing, and payment scams"
      icon={<Wallet className="w-8 h-8 text-green-400" />}
      placeholder="Paste suspicious UPI message, SMS, WhatsApp text, or call script here...&#10;&#10;Example: KYC update requests, QR code scans, OTP/PIN demands, screen share requests..."
      checkFunction={checkUpiMessage}
      sampleInputs={sampleInputs}
      accentColor="text-green-400"
    />
  );
}
