import { useState } from 'react';
import { motion } from 'framer-motion';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import { getRiskColor } from '@/lib/checkers';
import type { CheckResult } from '@/lib/checkers';
import {
  ClipboardList, Trash2, Search, Filter, X,
} from 'lucide-react';

type FilterType = 'ALL' | 'UPI' | 'PHISHING' | 'JOB';
type RiskFilter = 'ALL' | 'LOW' | 'MEDIUM' | 'HIGH';

export default function HistoryPage() {
  const [history, setHistory] = useLocalStorage<CheckResult[]>('scamshield_history', []);
  const [categoryFilter, setCategoryFilter] = useState<FilterType>('ALL');
  const [riskFilter, setRiskFilter] = useState<RiskFilter>('ALL');
  const [search, setSearch] = useState('');

  const filtered = history.filter((h) => {
    if (categoryFilter !== 'ALL' && h.category !== categoryFilter) return false;
    if (riskFilter !== 'ALL' && h.riskLevel !== riskFilter) return false;
    if (search && !h.matchedFlags.some((f) => f.description.toLowerCase().includes(search.toLowerCase()))) return false;
    return true;
  });

  const clearHistory = () => {
    if (window.confirm('Are you sure you want to clear all history?')) {
      setHistory([]);
    }
  };

  const deleteItem = (index: number) => {
    setHistory((prev) => prev.filter((_, i) => i !== index));
  };

  return (
    <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-green-500/10 border border-green-500/30 mb-4">
            <ClipboardList className="w-8 h-8 text-green-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 text-glow mb-2">Check History</h1>
          <p className="text-green-500/50">{history.length} total checks performed</p>
        </motion.div>

        {history.length === 0 ? (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card rounded-xl p-12 text-center border border-green-500/15"
          >
            <ClipboardList className="w-16 h-16 text-green-500/20 mx-auto mb-4" />
            <h3 className="text-xl font-bold text-green-400 mb-2">No History Yet</h3>
            <p className="text-green-500/50">Your scam check history will appear here.</p>
          </motion.div>
        ) : (
          <>
            {/* Filters */}
            <motion.div
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="glass-card rounded-xl p-4 border border-green-500/10 mb-6"
            >
              <div className="flex flex-wrap gap-3 items-center">
                <div className="relative flex-1 min-w-[200px]">
                  <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-green-500/40" />
                  <input
                    type="text"
                    value={search}
                    onChange={(e) => setSearch(e.target.value)}
                    placeholder="Search by flag description..."
                    className="w-full bg-black/50 border border-green-500/20 rounded-lg pl-10 pr-4 py-2 text-sm text-green-100 placeholder-green-500/30 focus:outline-none focus:border-green-500/50"
                  />
                </div>
                <div className="flex items-center gap-2">
                  <Filter className="w-4 h-4 text-green-500/40" />
                  {(['ALL', 'UPI', 'PHISHING', 'JOB'] as FilterType[]).map((cat) => (
                    <button
                      key={cat}
                      onClick={() => setCategoryFilter(cat)}
                      className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all ${
                        categoryFilter === cat
                          ? 'bg-green-500/20 text-green-400 border border-green-500/40'
                          : 'text-green-500/50 hover:text-green-400 border border-transparent'
                      }`}
                    >
                      {cat}
                    </button>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  {(['ALL', 'LOW', 'MEDIUM', 'HIGH'] as RiskFilter[]).map((risk) => {
                    const colors = risk === 'LOW' ? 'text-green-400 border-green-500/40 bg-green-500/20' :
                      risk === 'MEDIUM' ? 'text-yellow-400 border-yellow-500/40 bg-yellow-500/20' :
                      risk === 'HIGH' ? 'text-red-400 border-red-500/40 bg-red-500/20' :
                      'text-green-500/50 border-transparent';
                    return (
                      <button
                        key={risk}
                        onClick={() => setRiskFilter(risk)}
                        className={`px-3 py-1.5 rounded-lg text-xs font-medium transition-all border ${
                          riskFilter === risk ? colors : 'text-green-500/50 hover:text-green-400'
                        }`}
                      >
                        {risk === 'ALL' ? 'All' : risk}
                      </button>
                    );
                  })}
                </div>
                <button
                  onClick={clearHistory}
                  className="ml-auto inline-flex items-center gap-1 px-3 py-1.5 rounded-lg text-xs text-red-400 hover:bg-red-500/10 transition-all border border-red-500/20"
                >
                  <Trash2 className="w-3 h-3" /> Clear All
                </button>
              </div>
            </motion.div>

            {/* History List */}
            <div className="space-y-3">
              {filtered.map((item, i) => {
                const colors = getRiskColor(item.riskLevel);
                const date = new Date(item.checkedAt);
                return (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.03 }}
                    className="glass-card rounded-xl p-4 border border-green-500/10"
                  >
                    <div className="flex items-start justify-between gap-4">
                      <div className="flex-1 min-w-0">
                        <div className="flex items-center gap-2 mb-2 flex-wrap">
                          <span className="text-xs px-2 py-0.5 rounded-full bg-green-500/10 text-green-400 border border-green-500/20">
                            {item.category}
                          </span>
                          <span className={`text-xs px-2 py-0.5 rounded-full ${colors.light} ${colors.text} border ${colors.border}`}>
                            {item.riskLevel}
                          </span>
                          <span className="text-xs text-green-500/40">
                            {date.toLocaleDateString()} {date.toLocaleTimeString()}
                          </span>
                        </div>
                        <div className="flex items-center gap-3 mb-2">
                          <RiskMeter percentage={item.percentage} level={item.riskLevel} />
                          <div className="flex-1">
                            <p className="text-xs text-green-500/50 mb-1">
                              Score: <span className="text-green-400 font-mono">{item.score}/{item.maxScore}</span>
                              {' | '}
                              Flags: <span className="text-green-400">{item.matchedFlags.length}</span>
                            </p>
                            {item.matchedFlags.length > 0 && (
                              <div className="flex flex-wrap gap-1">
                                {item.matchedFlags.slice(0, 3).map((flag, fi) => (
                                  <span key={fi} className="text-[10px] px-2 py-0.5 rounded bg-red-500/10 text-red-400 border border-red-500/20 truncate max-w-[200px]">
                                    {flag.description}
                                  </span>
                                ))}
                                {item.matchedFlags.length > 3 && (
                                  <span className="text-[10px] px-2 py-0.5 rounded bg-green-500/10 text-green-400">
                                    +{item.matchedFlags.length - 3} more
                                  </span>
                                )}
                              </div>
                            )}
                          </div>
                        </div>
                      </div>
                      <button
                        onClick={() => deleteItem(i)}
                        className="p-1.5 rounded-lg hover:bg-red-500/10 text-green-500/30 hover:text-red-400 transition-all flex-shrink-0"
                      >
                        <X className="w-4 h-4" />
                      </button>
                    </div>
                  </motion.div>
                );
              })}
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function RiskMeter({ percentage, level }: { percentage: number; level: string }) {
  const color = level === 'LOW' ? 'bg-green-400' : level === 'MEDIUM' ? 'bg-yellow-400' : 'bg-red-400';
  return (
    <div className="w-16">
      <div className="w-16 h-16 rounded-full border-2 border-green-500/20 flex items-center justify-center mb-1">
        <span className={`text-sm font-bold ${level === 'LOW' ? 'text-green-400' : level === 'MEDIUM' ? 'text-yellow-400' : 'text-red-400'}`}>
          {percentage}%
        </span>
      </div>
      <div className="w-full h-1.5 rounded-full bg-green-500/10 overflow-hidden">
        <div className={`h-full rounded-full ${color}`} style={{ width: `${percentage}%` }} />
      </div>
    </div>
  );
}
