import { useState } from 'react';
import { motion } from 'framer-motion';
import {
  Flag, Send, CheckCircle, AlertTriangle,
  Phone, Globe, Shield,
} from 'lucide-react';

interface ScamReport {
  type: string;
  description: string;
  contact: string;
  date: string;
  reportedAt: string;
}

export default function ReportPage() {
  const [form, setForm] = useState({ type: '', description: '', contact: '', date: '' });
  const [submitted, setSubmitted] = useState(false);
  const [reports, setReports] = useState<ScamReport[]>([
    {
      type: 'UPI Fraud',
      description: 'Received SMS claiming Paytm KYC expired with phishing link',
      contact: 'SMS from +91-98XXXX1234',
      date: '2026-06-27',
      reportedAt: '2026-06-27T10:30:00',
    },
    {
      type: 'Job Scam',
      description: 'WhatsApp message offering work-from-home data entry job for Rs 5000/day, asked for Rs 999 registration',
      contact: 'WhatsApp: 87XXXX9087',
      date: '2026-06-26',
      reportedAt: '2026-06-26T14:15:00',
    },
    {
      type: 'Phishing',
      description: 'Email from "amaz0n.in" asking to verify account credentials',
      contact: 'email: support@amaz0n.in',
      date: '2026-06-25',
      reportedAt: '2026-06-25T09:00:00',
    },
  ]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.type || !form.description) return;
    setReports((prev) => [{
      type: form.type,
      description: form.description,
      contact: form.contact,
      date: form.date || new Date().toISOString().split('T')[0],
      reportedAt: new Date().toISOString(),
    }, ...prev]);
    setSubmitted(true);
    setForm({ type: '', description: '', contact: '', date: '' });
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className="inline-flex items-center justify-center w-16 h-16 rounded-xl bg-red-500/10 border border-red-500/30 mb-4">
            <Flag className="w-8 h-8 text-red-400" />
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 text-glow mb-2">Report a Scam</h1>
          <p className="text-green-500/50">Help others by reporting suspicious numbers, emails, and messages</p>
        </motion.div>

        {/* Emergency Banner */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          className="glass-card rounded-xl p-5 border border-red-500/20 mb-6 bg-red-500/5"
        >
          <div className="flex items-start gap-3">
            <AlertTriangle className="w-6 h-6 text-red-400 flex-shrink-0 mt-0.5" />
            <div>
              <h3 className="text-sm font-bold text-red-400 mb-1">In Immediate Danger?</h3>
              <p className="text-sm text-green-500/60 mb-2">
                If you have lost money or are being actively threatened, contact authorities immediately:
              </p>
              <div className="flex flex-wrap gap-3">
                <a href="tel:1930" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg bg-red-500 text-white text-sm font-semibold hover:bg-red-600 transition-all">
                  <Phone className="w-4 h-4" /> Call 1930
                </a>
                <a href="https://cybercrime.gov.in" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 px-4 py-2 rounded-lg border border-green-500/30 text-green-400 text-sm hover:bg-green-500/10 transition-all">
                  <Globe className="w-4 h-4" /> cybercrime.gov.in
                </a>
              </div>
            </div>
          </div>
        </motion.div>

        <div className="grid lg:grid-cols-5 gap-6">
          {/* Form */}
          <motion.div
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-3"
          >
            <div className="glass-card rounded-xl p-6 border border-green-500/10">
              <h3 className="text-lg font-bold text-green-400 mb-4 flex items-center gap-2">
                <Flag className="w-5 h-5" /> Submit Report
              </h3>

              {submitted && (
                <motion.div
                  initial={{ opacity: 0, y: -10 }}
                  animate={{ opacity: 1, y: 0 }}
                  className="mb-4 p-4 rounded-lg bg-green-500/10 border border-green-500/30 flex items-center gap-3"
                >
                  <CheckCircle className="w-5 h-5 text-green-400" />
                  <span className="text-sm text-green-400">Report submitted successfully! Thank you for helping keep others safe.</span>
                </motion.div>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div>
                  <label className="block text-sm text-green-400 mb-1">Scam Type *</label>
                  <select
                    value={form.type}
                    onChange={(e) => setForm({ ...form, type: e.target.value })}
                    className="w-full bg-black/50 border border-green-500/20 rounded-lg px-4 py-2.5 text-green-100 focus:outline-none focus:border-green-500/50"
                    required
                  >
                    <option value="">Select scam type</option>
                    <option value="UPI Fraud">UPI / Payment Fraud</option>
                    <option value="Phishing">Phishing / Email Scam</option>
                    <option value="Job Scam">Fake Job Offer</option>
                    <option value="OTP Fraud">OTP / PIN Theft</option>
                    <option value="Investment Scam">Investment / Crypto Scam</option>
                    <option value="Social Media Scam">Social Media Scam</option>
                    <option value="Other">Other</option>
                  </select>
                </div>

                <div>
                  <label className="block text-sm text-green-400 mb-1">Scammer Contact *</label>
                  <input
                    type="text"
                    value={form.contact}
                    onChange={(e) => setForm({ ...form, contact: e.target.value })}
                    placeholder="Phone number, email, WhatsApp number, URL..."
                    className="w-full bg-black/50 border border-green-500/20 rounded-lg px-4 py-2.5 text-green-100 placeholder-green-500/30 focus:outline-none focus:border-green-500/50"
                  />
                </div>

                <div>
                  <label className="block text-sm text-green-400 mb-1">Incident Date</label>
                  <input
                    type="date"
                    value={form.date}
                    onChange={(e) => setForm({ ...form, date: e.target.value })}
                    className="w-full bg-black/50 border border-green-500/20 rounded-lg px-4 py-2.5 text-green-100 focus:outline-none focus:border-green-500/50"
                  />
                </div>

                <div>
                  <label className="block text-sm text-green-400 mb-1">Description *</label>
                  <textarea
                    value={form.description}
                    onChange={(e) => setForm({ ...form, description: e.target.value })}
                    placeholder="Describe what happened, what they asked for, any links or numbers they used..."
                    rows={4}
                    className="w-full bg-black/50 border border-green-500/20 rounded-lg px-4 py-2.5 text-green-100 placeholder-green-500/30 focus:outline-none focus:border-green-500/50 resize-none"
                    required
                  />
                </div>

                <button
                  type="submit"
                  className="w-full inline-flex items-center justify-center gap-2 px-6 py-3 rounded-lg bg-red-500 text-white font-semibold hover:bg-red-600 transition-all hover:shadow-[0_0_20px_rgba(239,68,68,0.3)]"
                >
                  <Send className="w-4 h-4" />
                  Submit Report
                </button>
              </form>
            </div>
          </motion.div>

          {/* Recent Reports */}
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            className="lg:col-span-2"
          >
            <div className="glass-card rounded-xl p-5 border border-green-500/10">
              <h3 className="text-sm font-bold text-green-400 mb-4 flex items-center gap-2">
                <Shield className="w-4 h-4" /> Recent Community Reports
              </h3>
              <div className="space-y-3 max-h-[600px] overflow-y-auto pr-1">
                {reports.map((report, i) => (
                  <motion.div
                    key={i}
                    initial={{ opacity: 0, y: 10 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ delay: i * 0.05 }}
                    className="p-3 rounded-lg bg-green-500/5 border border-green-500/10"
                  >
                    <div className="flex items-center gap-2 mb-1">
                      <span className={`text-[10px] px-2 py-0.5 rounded-full border ${
                        report.type === 'UPI Fraud' ? 'border-green-500/30 text-green-400 bg-green-500/10' :
                        report.type === 'Phishing' ? 'border-blue-500/30 text-blue-400 bg-blue-500/10' :
                        report.type === 'Job Scam' ? 'border-purple-500/30 text-purple-400 bg-purple-500/10' :
                        'border-yellow-500/30 text-yellow-400 bg-yellow-500/10'
                      }`}>
                        {report.type}
                      </span>
                      <span className="text-[10px] text-green-500/40">{report.date}</span>
                    </div>
                    <p className="text-xs text-green-500/70 mb-1 line-clamp-2">{report.description}</p>
                    {report.contact && (
                      <p className="text-[10px] text-red-400/60 font-mono">{report.contact}</p>
                    )}
                  </motion.div>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
