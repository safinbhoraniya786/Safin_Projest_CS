import { useState } from 'react';
import { motion } from 'framer-motion';
import type { CheckResult } from '@/lib/checkers';
import ResultCard from '@/components/ResultCard';
import { useLocalStorage } from '@/hooks/useLocalStorage';
import {
  Shield, Loader2, Sparkles,
  FileText, AlertCircle, ChevronRight,
} from 'lucide-react';

interface CheckerPageProps {
  title: string;
  subtitle: string;
  icon: React.ReactNode;
  placeholder: string;
  checkFunction: (text: string) => CheckResult;
  sampleInputs: { label: string; text: string }[];
  accentColor: string;
}

export default function CheckerPage({
  title,
  subtitle,
  icon,
  placeholder,
  checkFunction,
  sampleInputs,
  accentColor,
}: CheckerPageProps) {
  const [input, setInput] = useState('');
  const [result, setResult] = useState<CheckResult | null>(null);
  const [isChecking, setIsChecking] = useState(false);
  const [, setHistory] = useLocalStorage<CheckResult[]>('scamshield_history', []);

  const handleCheck = async () => {
    if (!input.trim()) return;
    setIsChecking(true);
    setResult(null);

    // Simulate processing delay for UX
    await new Promise((r) => setTimeout(r, 800));

    const res = checkFunction(input);
    setResult(res);
    setHistory((prev) => [res, ...prev].slice(0, 100));
    setIsChecking(false);
  };

  const handleSample = (text: string) => {
    setInput(text);
    setResult(null);
  };

  return (
    <div className="min-h-screen pt-20 lg:pt-8 pb-8 px-4 relative z-10">
      <div className="max-w-4xl mx-auto">
        {/* Header */}
        <motion.div
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          className="text-center mb-8"
        >
          <div className={`inline-flex items-center justify-center w-16 h-16 rounded-xl ${accentColor} bg-opacity-10 border border-current mb-4`}>
            {icon}
          </div>
          <h1 className="text-3xl md:text-4xl font-bold text-green-400 text-glow mb-2">{title}</h1>
          <p className="text-green-500/50">{subtitle}</p>
        </motion.div>

        {/* Input Card */}
        <motion.div
          initial={{ opacity: 0, y: 10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ delay: 0.1 }}
          className="glass-card rounded-xl border border-green-500/15 mb-6"
        >
          <div className="p-5">
            <div className="flex items-center gap-2 mb-3">
              <FileText className="w-4 h-4 text-green-400" />
              <span className="text-sm font-medium text-green-400">Paste suspicious content</span>
            </div>
            <textarea
              value={input}
              onChange={(e) => setInput(e.target.value)}
              placeholder={placeholder}
              rows={6}
              className="w-full bg-black/50 border border-green-500/20 rounded-lg p-4 text-green-100 placeholder-green-500/30 focus:outline-none focus:border-green-500/50 focus:ring-1 focus:ring-green-500/20 resize-none font-mono text-sm leading-relaxed"
            />
            <div className="flex items-center justify-between mt-4">
              <span className="text-xs text-green-500/40">
                {input.length} characters
              </span>
              <button
                onClick={handleCheck}
                disabled={!input.trim() || isChecking}
                className={`inline-flex items-center gap-2 px-6 py-2.5 rounded-lg font-semibold transition-all ${
                  input.trim() && !isChecking
                    ? 'bg-green-500 text-black hover:bg-green-400 hover:shadow-[0_0_20px_rgba(34,197,94,0.3)]'
                    : 'bg-green-500/20 text-green-500/40 cursor-not-allowed'
                }`}
              >
                {isChecking ? (
                  <>
                    <Loader2 className="w-4 h-4 animate-spin" />
                    Analyzing...
                  </>
                ) : (
                  <>
                    <Shield className="w-4 h-4" />
                    Check for Scam
                  </>
                )}
              </button>
            </div>
          </div>
        </motion.div>

        {/* Sample Inputs */}
        {!result && !isChecking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.2 }}
            className="mb-6"
          >
            <div className="flex items-center gap-2 mb-3">
              <Sparkles className="w-4 h-4 text-green-400" />
              <span className="text-sm font-medium text-green-400">Try these examples</span>
            </div>
            <div className="grid gap-2">
              {sampleInputs.map((sample, i) => (
                <button
                  key={i}
                  onClick={() => handleSample(sample.text)}
                  className="flex items-center gap-3 p-3 rounded-lg bg-green-500/5 border border-green-500/10 hover:bg-green-500/10 hover:border-green-500/20 transition-all text-left group"
                >
                  <ChevronRight className="w-4 h-4 text-green-500/30 group-hover:text-green-400 transition-colors flex-shrink-0" />
                  <span className="text-sm text-green-500/60 group-hover:text-green-400 transition-colors truncate">
                    {sample.label}
                  </span>
                </button>
              ))}
            </div>
          </motion.div>
        )}

        {/* Scanning Animation */}
        {isChecking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="glass-card rounded-xl p-8 text-center border border-green-500/15 mb-6"
          >
            <div className="relative w-20 h-20 mx-auto mb-4">
              <div className="absolute inset-0 rounded-full border-2 border-green-500/20" />
              <div className="absolute inset-2 rounded-full border-2 border-green-500/30 animate-ping" />
              <div className="absolute inset-0 flex items-center justify-center">
                <Shield className="w-8 h-8 text-green-400 animate-pulse" />
              </div>
            </div>
            <h3 className="text-lg font-bold text-green-400 mb-2">Scanning for Red Flags</h3>
            <p className="text-sm text-green-500/50">Analyzing patterns, keywords, and risk indicators...</p>
            <div className="mt-4 flex justify-center gap-1">
              {[0, 1, 2].map((i) => (
                <motion.div
                  key={i}
                  className="w-2 h-2 rounded-full bg-green-400"
                  animate={{ opacity: [0.3, 1, 0.3] }}
                  transition={{ duration: 1, repeat: Infinity, delay: i * 0.2 }}
                />
              ))}
            </div>
          </motion.div>
        )}

        {/* Result */}
        {result && !isChecking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
          >
            <ResultCard result={result} />
          </motion.div>
        )}

        {/* Info Box */}
        {!result && !isChecking && (
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ delay: 0.3 }}
            className="mt-6 glass-card rounded-xl p-5 border border-yellow-500/15"
          >
            <div className="flex items-start gap-3">
              <AlertCircle className="w-5 h-5 text-yellow-400 flex-shrink-0 mt-0.5" />
              <div>
                <h4 className="text-sm font-bold text-yellow-400 mb-1">How it works</h4>
                <p className="text-xs text-green-500/50 leading-relaxed">
                  This checker scans your text against a database of known scam patterns using regex matching.
                  Each matched pattern adds a weighted score. The total score is converted to a percentage and
                  risk level (Low/Medium/High). This is a rule-based system — fully explainable and transparent.
                </p>
              </div>
            </div>
          </motion.div>
        )}
      </div>
    </div>
  );
}
